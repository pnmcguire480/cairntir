# Independent bounded R17 acceptance result

PASS on procedures SHA256
6d0ed499a601857aa41bd3d5fbba93b57cd6f391fa6409853423bc3e46974023.
21 fresh frozen controls plus subcases: zero failures/errors/skips, 0.922 seconds.
Controls and freeze hashes remain identical to the preimplementation baseline.
No product repairs were required by this acceptance lane.

Baseline PR125 head37ab0b1: two legacy controls passed. Nineteen governance
controls produced 50 missing-PracticeGovernance error events and zero assertion
failures. This is structural missing-capability evidence, not an asserted defect.

Deliberate stripping mutation in a separate source copy replaces governance with
None before propose/revise validation, retaining actual store/evaluation/operator
guards. Source SHA256
d9d8f7c8449104df18558e7ba062382db6b01c2838ba10101974dc9df8a5a941.
Same unchanged controls: 42 direct assertion failures, four downstream missing
metadata errors, zero skips, 1.000 seconds. Direct evidence includes None instead
of the requested PracticeGovernance, identical fingerprints when each governance
field changes, and invalid/stripped/reused-version writes accepted without the
required typed error. The four downstream errors are not counted as direct
causal assertion evidence. Positive lifecycle-only equality controls can pass
after stripping because None is consistently retained; initial metadata and
hash/negative controls independently expose that loss.

Historical original 24 plus additive Unicode four controls PASS unchanged:
28 tests, zero failures/errors/skips, 1.110 seconds. Direct historical runner is
blocked by missing plans/acceptance/PLAN.md; its original pre-PR125 store and
embedding predecessor pins also differ from this base. The separately hash-bound
run_historical_adapter.py changes orchestration only, verifies every original
assertion/fixture/runner hash, and uses current predecessor pins from fresh
freeze.json. This is adapted historical regression evidence, not a replay with
the old runner or old predecessors. Missing plan identity is not reconstructed.

All runs use tiny synthetic SQLite, deterministic32-dimensional hash embeddings,
isolated home/cache/temp roots, denied network/process launch/model imports. No
live data, installs, authorization changes or external services. Independent
lane ownership is procedural, not protected evaluator custody/authentication.
No claim of full R17/R18-R20, actual operator/host integration, concurrency across
distinct stores/processes, scheduling, or release qualification follows.

The hosted pytest adapter executes the exact frozen controls from controls.zip,
checks preimplementation freeze/assertion hashes, isolates each case and surfaces
unittest failures through normal pytest. ZIP entries have deterministic timestamps
and preserve raw hashes across LF/CRLF platforms. No synthetic database or isolated
home directory is shipped. Archived JSON/log receipts retain local source paths;
they contain synthetic inputs only.
