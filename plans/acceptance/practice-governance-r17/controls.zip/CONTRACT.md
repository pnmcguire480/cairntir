# Frozen independent bounded R17 contract

Tester owns this packet exclusively. Candidate begins at PR125 head
37ab0b1bb7e641adec8d2305b1546d1a35b1cd7e. Assertions are independently authored
before product implementation; historical acceptance was inspected read-only.

Optional frozen PracticeGovernance(owner, version, rationale, review_due) on
ProcedureSpec preserves omitted legacy spec payload, canonical drawer content and
SHA256 exactly. Primitive strings only: nonblank owner/version/rationale, version
without outer whitespace, valid UTF-8, exact real YYYY-MM-DD (past accepted).
Owner and rationale stay verbatim. All four fields bind spec/hash/content and
durable immutable append history. Every opted-in family retains governance and
uses an unused version on content revision; unrelated families may reuse labels.
Legacy families can opt in. Evaluation/corroboration/promotion/withdrawal retain
governance and revision identity. Existing independent evaluator and exact local
operator approval guards remain. Invalid proposals/revisions append nothing.
Malformed stored governance and mismatched hashes surface ProcedureError on
history/list reads that expose the affected record. No new get API is required.

No identity authentication, scheduler, MCP/Obsidian integration, new schema or
dependencies. This qualifies the finite metadata capability, not full R17/R18-R20.
Tiny synthetic SQLite plus deterministic HashEmbeddingProvider only. Network,
process launch and model imports denied; all home/cache locations isolated here.
Baseline absence is structural red, not an assertion-level defect reproduction.
Same frozen controls run on candidate then an isolated metadata-stripping copy;
direct assertion failures are separated from downstream errors. At most two
product repair rounds. No live stores, installs, migrations or credentials.
