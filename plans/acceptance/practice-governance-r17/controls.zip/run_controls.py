"""Pinned serial independent acceptance; never imports model providers."""
import argparse
import builtins
from contextlib import ExitStack
import hashlib
import importlib
import io
import json
import os
from pathlib import Path
import sys
import threading
import time
import types
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--source-sha256", required=True)
    parser.add_argument("--freeze-sha256", required=True)
    args = parser.parse_args()
    packet = Path(__file__).resolve().parent
    freeze = packet / "freeze.json"
    if sha(freeze) != args.freeze_sha256:
        raise RuntimeError("Freeze manifest drift")
    manifest = json.loads(freeze.read_text(encoding="utf-8"))
    for record in manifest["artifacts"]:
        if sha(packet / record["path"]) != record["sha256"]:
            raise RuntimeError("Frozen acceptance artifact drift")
    candidate = Path(args.candidate).resolve()
    source = candidate / "src/cairntir/procedures.py"
    if sha(source) != args.source_sha256:
        raise RuntimeError("Source identity mismatch")
    for record in manifest["predecessors"]:
        if sha(candidate / record["path"]) != record["sha256"]:
            raise RuntimeError("Unchanged predecessor mismatch")
    output = Path(args.output).resolve()
    if output.exists():
        raise RuntimeError("Refusing to overwrite evidence")
    output.mkdir(parents=True)
    for name in ("HOME", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "CAIRNTIR_HOME", "XDG_CACHE_HOME", "HF_HOME", "TRANSFORMERS_CACHE", "TORCH_HOME", "TMP", "TEMP"):
        value = output / "isolation" / name.lower()
        value.mkdir(parents=True)
        os.environ[name] = str(value)
    os.environ.update(CAIRNTIR_DISABLE_AUTOREGISTER="1", CAIRNTIR_DISABLE_UPDATE_CHECK="1", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", PYTHONPATH=str(candidate / "src"))
    package = types.ModuleType("cairntir")
    package.__path__ = [str(source.parent)]
    sys.modules["cairntir"] = package
    sys.path.insert(0, str(candidate / "src"))
    sys.path.insert(1, str(packet))
    importer = builtins.__import__
    def safe_import(name, *args, **kwargs):
        if name.split(".")[0] in {"fastembed", "onnxruntime", "sentence_transformers", "transformers", "torch", "huggingface_hub"}:
            raise AssertionError("Model dependency import denied")
        return importer(name, *args, **kwargs)
    def deny(*args, **kwargs):
        raise AssertionError("Network or process launch denied")
    timer = threading.Timer(45, lambda: os._exit(124))
    timer.daemon = True
    timer.start()
    started = time.monotonic()
    stream = io.StringIO()
    with ExitStack() as guards:
        for name in ("socket.socket.connect", "socket.create_connection", "subprocess.Popen", "subprocess.run", "os.system"):
            guards.enter_context(patch(name, side_effect=deny))
        guards.enter_context(patch("builtins.__import__", side_effect=safe_import))
        controls = importlib.import_module("controls")
        controls.API = importlib.import_module("cairntir.procedures")
        if Path(controls.API.__file__).resolve() != source:
            raise RuntimeError("Wrong candidate imported")
        controls.STORE = importlib.import_module("cairntir.memory.store").DrawerStore
        controls.DRAWER = importlib.import_module("cairntir.memory.taxonomy").Drawer
        controls.EMBEDDER = importlib.import_module("cairntir.memory.embeddings").HashEmbeddingProvider
        controls.MODEL = importlib.import_module("cairntir.reason.model")
        controls.ROOT = output
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(controls.FreshR17))
    timer.cancel()
    if sha(source) != args.source_sha256:
        raise RuntimeError("Candidate changed during acceptance")
    for record in manifest["artifacts"]:
        if sha(packet / record["path"]) != record["sha256"]:
            raise RuntimeError("Acceptance changed during run")
    log = output / "unittest.log"
    log.write_text(stream.getvalue(), encoding="utf-8")
    summary = dict(disposition="PASS" if result.wasSuccessful() else "FAIL", tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors), skips=len(result.skipped), failed_cases=[test.id() for test, _ in result.failures], error_cases=[test.id() for test, _ in result.errors], elapsed_seconds=round(time.monotonic() - started, 3), source_sha256=args.source_sha256, freeze_sha256=args.freeze_sha256, log_sha256=sha(log), synthetic=True, inference=False, network=False)
    (output / "result.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
