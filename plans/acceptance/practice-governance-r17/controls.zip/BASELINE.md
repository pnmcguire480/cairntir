# Baseline and ownership receipt

Author lane: /root/r17_acceptance. Exclusive writable acceptance packet:
C:\Users\pnmcg\Documents\Codex\2026-10-03\task\r17-acceptance.
No writes to candidate, historical controls, shared parent evidence, or live stores.

Candidate base: 37ab0b1bb7e641adec8d2305b1546d1a35b1cd7e.
Base procedures SHA256: 388b05e01690b105b37087696563a3ad0cc0cc43a432aaf20e2a3f25369566ec.
Freeze manifest SHA256: 11a824fefb828dbd705342495c39057a869826b5d20aac21fe8a38c9877dec2b.
Controls SHA256: b64fe7108f291ddf0b54f897989b028fb99ea556416c85584b610b23b333823c.
Runner SHA256: f21dc990249570aa5c3649a56274fab3768810794c2e819b4f67a3881a76e542.
Contract SHA256: db465bc4b375f41cbbe67051cbd41ed05efe82cbc29816ee4f72239ba2058906.

Baseline command, run serially from PowerShell:

```powershell
& 'C:\Users\pnmcg\.codex\worktrees\v2-foundation\Cairntir\.venv\Scripts\python.exe' `
  'C:\Users\pnmcg\Documents\Codex\2026-10-03\task\r17-acceptance\run_controls.py' `
  --candidate 'C:\Users\pnmcg\Documents\Codex\2026-10-03\task\cairntir-r17' `
  --output 'C:\Users\pnmcg\Documents\Codex\2026-10-03\task\r17-acceptance\baseline-red' `
  --freeze-sha256 11a824fefb828dbd705342495c39057a869826b5d20aac21fe8a38c9877dec2b `
  --source-sha256 388b05e01690b105b37087696563a3ad0cc0cc43a432aaf20e2a3f25369566ec
```

21 tests ran in 0.797 seconds: two legacy controls PASS, nineteen governance
controls structurally red, producing 50 error events including subtests and zero
assertion failures. Every error is missing PracticeGovernance. This proves absent
capability, not an assertion-level regression reproduction. Raw results and tiny
synthetic stores are retained under baseline-red; no baseline evidence overwritten.

User/parent corrected the accidental get requirement before freeze; canonical
scope has no get API. No assertions amended after the freeze or baseline run.
Unchanged source predecessors are pinned individually in freeze.json. Runtime
denies network/process launch/model imports and isolates home/cache/temp paths.
Shared-workspace authorship is independent by lane convention, not authentication.
