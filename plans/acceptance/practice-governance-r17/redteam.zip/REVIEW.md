# Independent finite R17 branch review

Disposition: **PASS for the approved finite metadata increment**. No product
repair requested. The broader malformed-registry-envelope probes are **FAIL**
on both candidate and base; that inherited limitation is retained below rather
than being counted as passing governance acceptance.

Reviewed base: `37ab0b1bb7e641adec8d2305b1546d1a35b1cd7e`, tree
`cb98d9d555dfbb9db466c15026b06f723369777b`.
Candidate branch: `feat/practice-governance-r17-20261003`; first candidate commit
`e98ca89`. Runtime source stayed identical throughout all review executions:
`src/cairntir/procedures.py` raw SHA256
`6d0ed499a601857aa41bd3d5fbba93b57cd6f391fa6409853423bc3e46974023`.

## Findings, prioritized

1. **Inherited Tier 3 limitation: malformed whole registry envelopes can leak
   untyped decoding errors.** Replacing a synthetic governed record's entire
   `procedure_records.payload` with `{`, `null`, `[]`, or `"record"` makes public
   `history` and `list(active_only=False)` raise `JSONDecodeError` or `TypeError`
   before the new `_procedure` guard is reached. The assertions require
   `ProcedureError`, producing eight direct assertion failures. Repeating the
   same four payloads and two reads using the exact-base procedure implementation
   and legacy records produces the identical eight failures. Relevant seam:
   `memory/store.py:883-902` decodes and mapping-expands registry payloads before
   `procedures.py:370-377` / `719-739` reconstruct specifications. This is outside
   the finite complete-governance-object/fingerprint contract, does not establish
   an API-produced corrupt record, and does not request an expanded store repair.
   The finite PASS does not imply general registry-corruption handling.

No new blocking defect was reproduced in the approved governance contract.

## Fresh independent evidence

- Original probe run: **19 PASS / 8 inherited FAIL**, candidate subprocess
  duration 0.986 seconds. Base comparison: **0 PASS / 8 identical FAIL**, 0.572
  seconds. `candidate.log`, `base.log`, and receipts retain all results unchanged.
- Additive independent probe run: **3 PASS / 0 FAIL**, 0.493 seconds. It checks
  entire legacy registry payload equality against base (including drawer content,
  IDs, and revision hash), opens a base-produced legacy store using candidate,
  checks historical/current version reuse, stripping and stale revisions after
  withdrawal, family-local labels, verbatim owner/rationale, and explicit access
  denial. Combined finite probes: **22 PASS**; the eight inherited failures remain
  separately disclosed, not removed or reclassified as passing assertions.
- Original controls reject governance dataclass and primitive-text subclasses;
  reject stored null/list/text/incomplete/extra/nested-object metadata using typed
  `ProcedureError`; bind all four changed fields and stripped metadata to hashes;
  preserve metadata and revision identity through evaluation, corroboration,
  promotion, withdrawal, and reopen. Owner attribution does not select an
  evaluator, supply operator approval, or bypass the store authorization hook.
- A deterministic two-connection intervention commits a competing revision
  between the losing call's initial validation and transaction. The losing call
  returns typed stale failure with exactly one competing revision retained.
- An intentionally injected nested registry JSON serialization failure after
  drawer insertion rolls back drawer, vector, registry and evaluation counts.
  Its injected `TypeError` is expected by this atomicity-only control; this is
  not evidence of typed handling for arbitrary internal seam failures.

Tests were independently authored and their hashes frozen before execution.
`FREEZE.json` and `EXTRA-FREEZE.json` preserve custody. Neither frozen original
assertions nor baseline red evidence was changed for the passing amendment.
`base_procedures.py` was extracted from the pinned Git revision using the Windows
shell; newline-normalized Git blob verification gives
`9eb2803b4c0aac8ebe168a0730a937eb13e07069`, exactly the base procedure blob.
The shared store implementation's Git blob is
`9e9a83ddfc7e706e0f41dc539ee3e22bb3085438`, also exactly the base blob.
All synthetic SQLite stores used `HashEmbeddingProvider(dimension=16)`.
Home, config, caches, temporary directories and grant-related environment
isolation were confined to the review packet; network connections were forbidden
inside probes. Only lightweight serial Python verification processes ran.

## Diff and documentation review

Reviewed the complete runtime delta (+83/-16), new dedicated source regressions,
operator/API documentation, finite plan, and later independent pytest adapter.
Runtime adds no schema, dependency, tool, scheduler, authority mechanism or
Obsidian/correction import. `_spec_payload` omits the added field for legacy
specifications, and `_procedure` validates complete opted-in objects and
fingerprints on exposing reads. Version reuse checks and opt-out refusal run
inside the existing `BEGIN IMMEDIATE` transaction. Evaluation/operator/access
checks retain their previous locations and remain independent of owner labels.

Documentation accurately scopes stored review intent, family versions, immutable
API history, and old-reader downgrade limitations. It retains full connected R17,
R18-R20, integration and release qualification as separate work. The independent
pytest adapter binds original frozen assertions and collection by hash. Parent
reported 89 passing dedicated/frozen/existing procedure tests; this review does
not substitute that report for this packet's own independently executed probes.

## Confidence limits

High confidence in the bounded metadata behavior and the inherited decoding
finding on the pinned runtime bytes. Two-connection stale intervention is a
deterministic transaction recheck proof, not sustained parallel load testing.
No models, live stores, network calls, installations, credentials, migrations,
merges, releases or paid services were exercised. No assurance of resistance to
an attacker rewriting both SQLite payloads and fingerprints is claimed; hashes
bind recorded content, while trusted local registry custody remains the existing
boundary. History completeness against direct row deletion and full downgrade,
host, operator identity and connected governance qualification remain unproven.
Full hosted exact-head CI and parent integration remain external gates.

Only this reviewer-owned directory was written. Public archive packaging excludes
all runtime directories and databases and preserves included evidence bytes.
