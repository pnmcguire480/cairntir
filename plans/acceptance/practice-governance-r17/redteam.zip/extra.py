"""Additive frozen review controls; original red evidence stays intact."""
import importlib.util
import json
import socket
import sys
from dataclasses import replace
from pathlib import Path

from cairntir import procedures as api
from cairntir.errors import CairntirError
from cairntir.memory.embeddings import HashEmbeddingProvider
from cairntir.memory.store import DrawerStore
from cairntir.memory.taxonomy import Drawer

ROOT = Path(__file__).resolve().parent
RUNTIME = Path(sys.argv[1])
loader = importlib.util.spec_from_file_location("extra_frozen_base", ROOT / "base_procedures.py")
base = importlib.util.module_from_spec(loader)
sys.modules[loader.name] = base
loader.loader.exec_module(base)
def forbid(*args, **kwargs):
    raise AssertionError("network prohibited")
socket.socket.connect = forbid
socket.create_connection = forbid
results = []

def run(name, action):
    try:
        action()
        result = {"name": name, "status": "PASS"}
    except Exception as exc:
        result = {"name": name, "status": "FAIL", "error": type(exc).__name__, "message": str(exc)}
    results.append(result)
    print(json.dumps(result), flush=True)

def spec_for(module, store):
    d = store.add(Drawer(wing="probe", room="cases", content="development"))
    return module.ProcedureSpec("Practice", ["Synthetic"], "Here", ["Act"], "ok", ["Undo"], [d.id])

def snapshot(module, file):
    with DrawerStore(file, HashEmbeddingProvider(dimension=16)) as store:
        spec = spec_for(module, store)
        p = module.ProcedureBook(store, {}).propose(wing="probe", spec=spec)
        return p.drawer_id, p.revision_sha256, store.get(p.drawer_id).content, store._conn.execute("SELECT payload FROM procedure_records WHERE drawer_id=?", (p.drawer_id,)).fetchone()[0]

def exact_legacy():
    old = snapshot(base, RUNTIME / "legacy-base.db")
    new = snapshot(api, RUNTIME / "legacy-candidate.db")
    assert old == new, "omitted governance changed entire stored registry, drawer content, IDs, or revision"
    with DrawerStore(RUNTIME / "legacy-base.db", HashEmbeddingProvider(dimension=16)) as store:
        history = api.ProcedureBook(store, {}).history(old[0])
        assert len(history) == 1 and history[0].revision_sha256 == old[1]
        assert history[0].spec.governance is None
        assert store.get(old[0]).content == old[2]
run("legacy/base-candidate-entire-registry-content-hash-reopen", exact_legacy)

def counts(store):
    return tuple(store._conn.execute("SELECT count(*) FROM " + table).fetchone()[0] for table in ("drawers", "vec_drawers", "procedure_records"))

def typed(action):
    try:
        action()
    except api.ProcedureError:
        return
    raise AssertionError("expected ProcedureError")

def versions():
    with DrawerStore(RUNTIME / "versions.db", HashEmbeddingProvider(dimension=16)) as store:
        spec = spec_for(api, store)
        book = api.ProcedureBook(store, {})
        legacy = book.propose(wing="probe", spec=spec)
        governed = replace(spec, governance=api.PracticeGovernance(" exact owner ", "v1", "exact\nrationale ", "0001-01-01"))
        first = book.revise(legacy.drawer_id, spec=governed)
        v2 = replace(governed, governance=replace(governed.governance, version="v2"))
        second = book.revise(first.drawer_id, spec=v2)
        withdrawal = book.rollback(second.drawer_id, reason="synthetic")
        before = counts(store)
        for stale in (legacy, first, second):
            typed(lambda p=stale: book.revise(p.drawer_id, spec=replace(governed, governance=replace(governed.governance, version="v3"))))
            assert counts(store) == before
        for invalid in (spec, governed, v2):
            typed(lambda s=invalid: book.revise(withdrawal.drawer_id, spec=s))
            assert counts(store) == before
        other = book.propose(wing="probe", spec=governed)
        assert other.spec.governance.version == "v1"
        chain = book.history(withdrawal.drawer_id)
        assert [p.spec.governance.version if p.spec.governance else None for p in chain] == [None, "v1", "v2", "v2"]
        assert first.spec.governance.owner == " exact owner "
        assert first.spec.governance.rationale == "exact\nrationale "
run("versions/legacy-optin-strip-reuse-stale-cross-family-history", versions)

def denied_labels():
    class Denied(CairntirError):
        pass
    with DrawerStore(RUNTIME / "access.db", HashEmbeddingProvider(dimension=16)) as store:
        spec = spec_for(api, store)
        spec = replace(spec, governance=api.PracticeGovernance("owner", "1", "trusted operator", "2026-01-01"))
        book = api.ProcedureBook(store, {}, operator_approval=lambda request: True)
        p = book.propose(wing="probe", spec=spec)
        before = counts(store)
        calls = []
        def deny(capability, **scope):
            calls.append((capability, scope))
            raise Denied("synthetic denial")
        store.authorize = deny
        for action in (lambda: book.propose(wing="probe", spec=spec), lambda: book.revise(p.drawer_id, spec=spec), lambda: book.history(p.drawer_id), lambda: book.list(wing="probe", active_only=False), lambda: book.promote(p.drawer_id, evaluation_id=1)):
            try:
                action()
            except Denied:
                pass
            else:
                raise AssertionError("metadata labels bypassed explicit store denial")
            assert counts(store) == before
        assert [capability for capability, _ in calls] == ["write", "read", "read", "read", "approve"]
run("authority/labels-cannot-bypass-explicit-store-denial", denied_labels)

summary = {"pass": sum(r["status"] == "PASS" for r in results), "fail": sum(r["status"] == "FAIL" for r in results), "results": results}
(RUNTIME / "results.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
sys.exit(bool(summary["fail"]))
