"""Independently authored, tiny synthetic R17 adversarial assertions."""
import hashlib
import importlib.util
import json
import socket
import sys
from dataclasses import asdict, dataclass, replace
from pathlib import Path

from cairntir import procedures as candidate
from cairntir.errors import CairntirError
from cairntir.memory.embeddings import HashEmbeddingProvider
from cairntir.memory.store import DrawerStore
from cairntir.memory.taxonomy import Drawer
from cairntir.reason.model import Experiment, Outcome

ROOT = Path(__file__).resolve().parent
MODE = sys.argv[1]
api = candidate
if MODE == "base":
    loader = importlib.util.spec_from_file_location("frozen_base_procedures", ROOT / "base_procedures.py")
    api = importlib.util.module_from_spec(loader)
    sys.modules[loader.name] = api
    loader.loader.exec_module(api)

def forbidden(*args, **kwargs):
    raise AssertionError("network forbidden by synthetic review")

socket.socket.connect = forbidden
socket.create_connection = forbidden
results = []
serial = 0

def run(name, fn):
    try:
        fn()
        result = {"name": name, "status": "PASS"}
    except Exception as exc:
        result = {"name": name, "status": "FAIL", "error": type(exc).__name__, "message": str(exc)}
    results.append(result)
    print(json.dumps(result, ensure_ascii=True), flush=True)

def bundle():
    global serial
    serial += 1
    db = Path(sys.argv[2]) / ("case-%02d.db" % serial)
    store = DrawerStore(db, HashEmbeddingProvider(dimension=16))
    evidence = store.add(Drawer(wing="probe", room="cases", content="development"))
    spec = api.ProcedureSpec("Practice", ("Synthetic",), "Here", ("candidate",), "ok", ("Undo",), (evidence.id,))
    if MODE != "base":
        spec = replace(spec, governance=api.PracticeGovernance("  operator\n", "1", " rationale\n ", "2000-02-29"))
    return db, store, api.ProcedureBook(store, {}), spec

def counts(store):
    return tuple(store._conn.execute("SELECT count(*) FROM " + table).fetchone()[0]
                 for table in ("drawers", "vec_drawers", "procedure_records", "procedure_evaluations"))

def typed(fn):
    try:
        fn()
    except api.ProcedureError:
        return
    except Exception as exc:
        raise AssertionError("Expected ProcedureError; got %s: %s" % (type(exc).__name__, exc)) from exc
    raise AssertionError("Expected ProcedureError; operation succeeded")

def corrupt(payload, read):
    _, store, book, spec = bundle()
    try:
        p = book.propose(wing="probe", spec=spec)
        before = counts(store)
        store._conn.execute("UPDATE procedure_records SET payload=? WHERE drawer_id=?", (payload, p.drawer_id))
        typed(lambda: book.history(p.drawer_id) if read == "history" else book.list(wing="probe", active_only=False))
        assert counts(store) == before
    finally:
        store.close()

for payload_name, payload in (("invalid-json", "{"), ("null", "null"), ("array", "[]"), ("string", '"record"')):
    for read in ("history", "list"):
        run("registry-envelope/%s/%s" % (payload_name, read), lambda p=payload, r=read: corrupt(p, r))

if MODE != "base":
    class TextSubclass(str):
        pass

    @dataclass(frozen=True)
    class GovernanceSubclass(api.PracticeGovernance):
        pass

    def invalid_input(value):
        _, store, book, spec = bundle()
        try:
            p = book.propose(wing="probe", spec=spec)
            invalid = replace(spec, governance=value)
            before = counts(store)
            typed(lambda: book.propose(wing="probe", spec=invalid))
            typed(lambda: book.revise(p.drawer_id, spec=invalid))
            assert counts(store) == before
        finally:
            store.close()

    for name, value in (("dict", {}), ("object", object()),
                        ("subclass", GovernanceSubclass("x", "2", "why", "2026-01-01")),
                        ("owner-text-subclass", api.PracticeGovernance(TextSubclass("x"), "2", "why", "2026-01-01")),
                        ("version-text-subclass", api.PracticeGovernance("x", TextSubclass("2"), "why", "2026-01-01"))):
        run("invalid-input/" + name, lambda v=value: invalid_input(v))

    def nested_corrupt(mutator):
        _, store, book, spec = bundle()
        try:
            p = book.propose(wing="probe", spec=spec)
            row = json.loads(store._conn.execute("SELECT payload FROM procedure_records WHERE drawer_id=?", (p.drawer_id,)).fetchone()[0])
            mutator(row)
            before = counts(store)
            store._conn.execute("UPDATE procedure_records SET payload=? WHERE drawer_id=?", (json.dumps(row), p.drawer_id))
            typed(lambda: book.history(p.drawer_id))
            typed(lambda: book.list(wing="probe", active_only=False))
            assert counts(store) == before
        finally:
            store.close()

    for field in ("owner", "version", "rationale", "review_due"):
        run("hash-tamper/" + field, lambda f=field: nested_corrupt(lambda r: r["spec"]["governance"].__setitem__(f, "2027-01-01" if f == "review_due" else "changed")))
    for name, value in (("null", None), ("list", []), ("text", "label"), ("incomplete", {"owner": "x"}),
                        ("extra-field", {"owner": "x", "version": "1", "rationale": "y", "review_due": "2026-01-01", "extra": True}),
                        ("nested-object", {"owner": {"label": "x"}, "version": "1", "rationale": "y", "review_due": "2026-01-01"})):
        run("stored-governance/" + name, lambda v=value: nested_corrupt(lambda r: r["spec"].__setitem__("governance", v)))
    run("hash-tamper/stripped-governance", lambda: nested_corrupt(lambda r: r["spec"].pop("governance")))

    def lifecycle():
        db, store, _, spec = bundle()
        try:
            cases = []
            for index in range(2):
                evidence = store.add(Drawer(wing="probe", room="cases", content="holdout-%d" % index))
                cases.append(api.HoldoutCase("h%d" % index, evidence.id, "ok"))
            class Runner:
                def run(self, hypothesis):
                    material = json.loads(hypothesis.claim)
                    good = material["steps"] == ["candidate"]
                    return Outcome(Experiment(hypothesis, "synthetic"), "ok" if good else "bad", good, "")
            manifest = api.EvaluationManifest("trusted", ("baseline",), tuple(cases))
            registry = {"trusted": api.RegisteredEvaluation(manifest, Runner())}
            book = api.ProcedureBook(store, registry)
            p = book.propose(wing="probe", spec=spec)
            original_payload = store._conn.execute("SELECT payload FROM procedure_records WHERE drawer_id=?", (p.drawer_id,)).fetchone()[0]
            before = counts(store)
            typed(lambda: book.evaluate(p.drawer_id, evaluator_id=spec.governance.owner))
            assert counts(store) == before
            receipt = book.evaluate(p.drawer_id, evaluator_id="trusted")
            assert receipt.passed
            before = counts(store)
            typed(lambda: book.promote(receipt.current_id, evaluation_id=receipt.drawer_id))
            assert counts(store) == before
            book = api.ProcedureBook(store, registry, operator_approval=lambda request: True)
            promoted = book.promote(receipt.current_id, evaluation_id=receipt.drawer_id)
            withdrawn = book.rollback(promoted.drawer_id, reason="review")
            chain = book.history(withdrawn.drawer_id)
            assert [p.state for p in chain] == ["candidate", "corroborated", "promoted", "expired"]
            assert all(p.spec.governance == spec.governance and p.revision_sha256 == chain[0].revision_sha256 for p in chain)
            assert store._conn.execute("SELECT payload FROM procedure_records WHERE drawer_id=?", (p.drawer_id,)).fetchone()[0] == original_payload
            expected = chain
        finally:
            store.close()
        with DrawerStore(db, HashEmbeddingProvider(dimension=16)) as reopened:
            assert api.ProcedureBook(reopened, {}).history(withdrawn.drawer_id) == expected
    run("lifecycle/authority-preservation-reopen", lifecycle)

    def stale_interleaving():
        db, store, book, spec = bundle()
        try:
            p = book.propose(wing="probe", spec=spec)
            with DrawerStore(db, HashEmbeddingProvider(dimension=16)) as other:
                competing = api.ProcedureBook(other, {})
                validate = book._validate_spec
                winner = []
                def intervene(wing, incoming):
                    validate(wing, incoming)
                    winner.append(competing.revise(p.drawer_id, spec=replace(spec, governance=replace(spec.governance, version="2"))))
                book._validate_spec = intervene
                typed(lambda: book.revise(p.drawer_id, spec=replace(spec, governance=replace(spec.governance, version="3"))))
                assert len(book.history(winner[0].drawer_id)) == 2
                assert counts(store)[2] == 2
        finally:
            store.close()
    run("atomicity/two-connection-stale-interleaving", stale_interleaving)

    def serialization_failure():
        _, store, book, spec = bundle()
        try:
            before = counts(store)
            original = store._register_procedure
            def fail(*args, **kwargs):
                kwargs["payload"]["spec"]["governance"]["owner"] = object()
                return original(*args, **kwargs)
            store._register_procedure = fail
            try:
                book.propose(wing="probe", spec=spec)
                raise AssertionError("injected nested serialization failure was ignored")
            except TypeError:
                pass
            assert counts(store) == before, "nested registry JSON serialization left partial drawer/vector records"
        finally:
            store.close()
    run("atomicity/injected-nested-serialization-failure", serialization_failure)

summary = {"mode": MODE, "pass": sum(r["status"] == "PASS" for r in results), "fail": sum(r["status"] == "FAIL" for r in results), "results": results}
Path(sys.argv[2], "results.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps({k: v for k, v in summary.items() if k != "results"}))
sys.exit(bool(summary["fail"]))
