import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
CANDIDATE = ROOT.parent / "cairntir-r17"
runtime = ROOT / "runtime-extra"
runtime.mkdir(exist_ok=False)
freeze = json.loads((ROOT / "EXTRA-FREEZE.json").read_text(encoding="utf-8"))
for relative, expected in freeze.items():
    assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == expected
env = os.environ.copy()
for name in ("HOME", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "XDG_CONFIG_HOME", "XDG_CACHE_HOME", "XDG_DATA_HOME", "CAIRNTIR_HOME", "HF_HOME", "MYPY_CACHE_DIR", "RUFF_CACHE_DIR", "UV_CACHE_DIR", "TEMP", "TMP"):
    location = runtime / name.lower()
    location.mkdir()
    env[name] = str(location)
env.update(PYTHONPATH=str(CANDIDATE / "src"), PYTHONDONTWRITEBYTECODE="1", CAIRNTIR_DISABLE_AUTOREGISTER="1", CAIRNTIR_DISABLE_UPDATE_CHECK="1", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", NUMEXPR_NUM_THREADS="1", TOKENIZERS_PARALLELISM="false")
for name in list(env):
    if name.startswith("CAIRNTIR_GRANT") or name == "CAIRNTIR_ACCESS_TOKEN":
        del env[name]
source = hashlib.sha256((CANDIDATE / "src/cairntir/procedures.py").read_bytes()).hexdigest()
command = [r"C:\Users\pnmcg\.codex\worktrees\v2-foundation\Cairntir\.venv\Scripts\python.exe", str(ROOT / "extra.py"), str(runtime)]
start = time.perf_counter()
result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=45)
data = result.stdout + result.stderr
(ROOT / "extra.log").write_bytes(data)
receipt = {"command": command, "seconds": round(time.perf_counter() - start, 3), "exit_code": result.returncode, "source_sha256": source, "probe_freeze": freeze, "log_sha256": hashlib.sha256(data).hexdigest(), "synthetic_only": True}
(ROOT / "extra-receipt.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
print(data.decode("utf-8"))
print(json.dumps(receipt))
raise SystemExit(result.returncode)
