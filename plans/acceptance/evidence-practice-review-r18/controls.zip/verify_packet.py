"""Verify deterministic bytes, every original entry, and no runtime artifacts."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
subprocess.run([sys.executable, str(HERE / "package_controls.py")], check=True, capture_output=True, timeout=20)
first = (HERE / "controls.zip").read_bytes()
subprocess.run([sys.executable, str(HERE / "package_controls.py")], check=True, capture_output=True, timeout=20)
second = (HERE / "controls.zip").read_bytes()
assert first == second, "Archive is not deterministic"
with zipfile.ZipFile(io.BytesIO(second)) as archive:
    manifest = json.loads(archive.read("MANIFEST.json"))
    for name, expected in manifest.items():
        data = archive.read(name)
        assert hashlib.sha256(data).hexdigest() == expected
        assert data == (HERE / name).read_bytes()
        assert not name.endswith((".db", ".sqlite", ".sqlite3", ".db-wal", ".db-shm"))
        if name.endswith(".zip"):
            with zipfile.ZipFile(io.BytesIO(data)) as nested:
                for nested_name in nested.namelist():
                    assert nested_name.startswith("src/"), nested_name
                    assert not nested_name.endswith((".db", ".sqlite", ".sqlite3", ".pyc"))
    candidate = json.loads(archive.read("candidate-source-identity.json"))
    run = json.loads(archive.read("candidate-round1.json"))
    assert candidate["file_sha256"]["src/cairntir/procedures.py"] == run["source_sha256"]
    assert candidate["file_sha256"]["src/cairntir/procedures.py"] == hashlib.sha256((HERE.parent / "cairntir-r18/src/cairntir/procedures.py").read_bytes()).hexdigest()
    adapter = json.loads(archive.read("pytest-adapter-freeze.json"))
    assert adapter["adapter_sha256"] == hashlib.sha256(archive.read("test_practice_reviews_independent.py")).hexdigest()
report = {"zip_sha256": hashlib.sha256(second).hexdigest(), "zip_bytes": len(second), "entry_count": len(manifest)+1, "two_builds_byte_identical": True, "every_original_entry_byte_verified": True, "no_database_or_runtime_home_entries": True, "final_source_sha256": run["source_sha256"], "frozen_assertions_sha256": run["assertions_sha256"]}
(HERE / "packet-verification.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
