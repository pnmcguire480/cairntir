# R18 evidence-driven practice review: implementation contract

Parent request: Continue the authorized hybrid roadmap with R18 on qualified PR128
head 9e65c37c9a734f88d54935933047bda598e03146, tree
5ee79667e3923dc30237249b4b65194fdf983995. Main owns R08 question/store/CLI/Obsidian/
plugin/shared release work. Implement, independently test/red-team/harden and
qualify exact-head CI/CodeQL in a draft PR; no merge/release/install/live adoption,
access changes, paid model calls or another feature.

## Existing requirement, not a substitute feature

The preserved independent full-product register at
C:/Users/pnmcg/AppData/Local/Temp/cairntir-final-0930/plans/acceptance/home-finalization-20260930/ACCEPTANCE.md
defines R18: actual trigger/false-positive/override/impact evidence, due/evidence-
triggered review; a simulated quarter never claims a field quarter. The preserved
docs/plans/2026-10-01-ideation-lessons.md additionally says absent R18 metrics stay
unknown. These are the existing scope sources; current PR128 has no R18 execution
plan. This contract implements that public capability; synthetic qualification
does not supply actual production usage or a measured field quarter.

## Ownership and architecture

Isolated branch feat/evidence-practice-review-r18-20261003 in cairntir-r18;
no-hardlink clone, exact base/tree independently verified against GitHub. Runtime
only src/cairntir/procedures.py. New dedicated tests/docs/plan/evidence are allowed.
No store/schema/access adapter, question module, CLI, Obsidian/plugin, dependency,
shared version/changelog/navigation edits. Persist tagged observation/review records
atomically in existing drawers plus procedure_evaluations ledger using existing
scoped methods. This ledger is already generic JSON keyed by drawer. New tags are
explicitly rejected by get_evaluation; they can never satisfy promotion. All
reference IDs use the scoped adapter's existing recognized reference names.
No procedure transition is appended for telemetry/review: spec, revision, active
state, evaluation and approval stay unchanged. Legacy registry/spec bytes stay exact.

Collection uses list_by(wing,room='practice-reviews',limit=None,include_expired=True)
and authenticated ledger lookups, not arbitrary metadata as proof. Copied/forged
metadata-only room entries are ignored by collection because they have no registry
origin; direct get_observation/get_review rejects them. An authenticated ledger
entry in the owned room with wrong schema/type/hash fails typed rather than being
silently omitted. Existing scoped visibility and
AccessDenied remain authoritative; partial visibility cannot become complete stats.
Old clients can read ordinary procedures unchanged; new review ledger IDs are not
holdout evaluation IDs. The trusted Python API is the explicit host integration;
there is no new MCP/CLI command, background timer or automatic policy execution.

Normal PR CI/CodeQL filters omit PR128's branch. Parent must coordinate adding only
feat/obsidian-practice-integration-20261003 to their existing base branch filters.
Do not edit those shared files until coordinated; prepare the exact two-line patch.

## Public API and immutable values

PracticeObservation(event_id, observed_on, origin, triggered, false_positive,
overridden, baseline_impact, practice_impact, impact_unit, evidence_ids).
origin is observed|simulated|unknown, an attributed classification rather than
authenticated field truth. observed_on is a canonical calendar date. The three
flags are exact bool or None; false_positive/overridden apply only when triggered
is True (otherwise must be None). Impact is a finite paired numeric measurement
or both None, with an explicit unit iff measured. Exact primitive UTF-8 nonblank
bounded event/unit strings; unique nonempty positive integer evidence IDs. Freeze
caller sequences. Source evidence must exist in the same wing; snapshot hashes
bind it to the record. No inferred zero, fabricated evidence or silently dropped
malformed data. Observed-origin recording requires an authenticated promoted
target; historical promoted revisions can receive late observations. Simulated/
unknown records may target an authenticated governed non-withdrawn revision.

PracticeReviewPolicy(minimum_observations, minimum_trigger_rate=None,
maximum_false_positive_rate=None, maximum_override_rate=None,
minimum_mean_impact=None, impact_unit=None). Minimum is an explicit positive exact
int. Optional finite rate thresholds are [0,1]; impact threshold has explicit unit.
No product-specific default threshold is invented. At least one evidence threshold
must be declared. Policy and all selected observations bind the assessment hash.

ProcedureBook methods:
- record_observation(drawer_id, *, observation, supersedes_id=None): authentic
  immutable receipt. event_id is unique within family/content revision. Exact
  replay returns the existing receipt; changed replay without explicit correction
  fails. Correction must reference the latest same event/revision, appends without
  overwriting, and rejects stale branches atomically. Registration/write failures
  preserve original history and do not leave orphan records; clean retry succeeds.
- get_observation(observation_id), observation_history(drawer_id): authenticated
  exact record/all family history including prior content versions and corrections.
- assess_review(drawer_id, *, period_start, period_end, as_of, policy): read-only
  current governed revision assessment. Dates are explicit canonical UTC-calendar
  dates; start<end, start<as_of. Select latest corrected events in the half-open
  [start,min(end,as_of)) window, separately by origin. No clock or full-quarter
  completeness is invented. Include observed/simulated/unknown cohorts and measured/
  missing counts; empty metrics stay None. Trigger rate = triggered/eligible events
  only when all trigger flags known. False-positive/override rate uses triggered
  events only; unknown trigger eligibility or missing applicable flag makes rate
  unknown. Zero triggered denominator makes those rates unknown. Mean impact =
  mean(practice-baseline) only when all impact pairs known and units agree; mixed
  units fail rather than combine. Nonfinite arithmetic fails typed.
- Due reason applies when effective review_due<=as_of. Effective date is initial
  governance date, then latest completion's explicit next date for that content
  revision. Evidence reasons come only from observed cohort, adequate corresponding
  denominator/sample size and strict threshold breach. Equality is not a breach.
  Simulated/unknown evidence cannot trigger field-evidence review. Already reviewed
  observation snapshots are not repeatedly alerted; genuinely new/corrected observed
  evidence can trigger again. Metrics remain visible even after acknowledgement.
- complete_review(drawer_id, *, assessment, reviewer, decision, rationale,
  next_review_due): retain|revise|defer, attributed reviewer/rationale, future
  canonical next date strictly after assessment.as_of. Recompute/compare exact
  assessment/current revision/latest evidence under existing transaction before
  append. Stale, forged or changed evidence rejects without writes. Exact completion
  replay returns existing receipt; another completion must have a fresh assessment.
  Decisions record review outcome, never change content, promote/withdraw, execute
  repairs or authenticate identity. Reviewed date is the explicit assessment.as_of.
- get_review(review_id), review_history(drawer_id): exact authenticated immutable
  outcomes and assessments across family versions, surviving reopen.
- due_reviews(*, wing, period_start, period_end, as_of, policy): assessments with
  reasons for current promoted governed practices only. Legacy/nonactive methods
  are outside opt-in queue; no scheduler or silent migration.

New frozen receipt/metric/assessment classes expose IDs, content revision/version,
origin counts, known/missing counts, exact policy, evidence/record hashes, reasons,
effective deadline and immutable reviewer decisions. All new stored formats have
strict shape/type/hash checks; errors surface as ProcedureError, with existing
AccessDenied/store errors kept distinct. Existing promotion/evaluation guards and
legacy wire/state/history must pass unchanged. No blanket damaged-store claim.

## Concrete result fields and bounds (settled before test freeze)

All values below are frozen dataclasses. Sequence inputs are detached as tuples.

- PracticeObservationReceipt(drawer_id:int, procedure_id:int, root_id:int,
  revision_sha256:str, observation:PracticeObservation, supersedes_id:int|None,
  evidence_sha256:tuple[str,...], record_sha256:str). Evidence hashes correspond
  exactly to observation.evidence_ids in caller order. record_sha256 binds the
  authenticated target/revision, observation, source hashes and predecessor.
- PracticeMetrics(origin:str, observation_count:int, triggered_count:int,
  trigger_known:int, trigger_unknown:int, false_positive_known:int,
  false_positive_unknown:int, override_known:int, override_unknown:int,
  impact_known:int, impact_unknown:int, trigger_rate:float|None,
  false_positive_rate:float|None, override_rate:float|None,
  mean_impact:float|None, impact_unit:str|None). Applicable known false-positive/
  override counts are only triggered=True events; unknown count additionally
  includes events with unknown eligibility. impact_unit is the one measured unit
  or None if no known pair. Zero denominators and any missing eligible value keep
  the corresponding metric None, rather than an observed-subset estimate.
- PracticeReviewAssessment(procedure_id:int, root_id:int, revision_sha256:str,
  version:str, period_start:str, period_end:str, as_of:str,
  effective_review_due:str, last_review_id:int|None,
  policy:PracticeReviewPolicy, metrics:tuple[PracticeMetrics,...],
  observation_ids:tuple[int,...], observation_sha256:tuple[str,...],
  evidence_ids:tuple[int,...], reasons:tuple[str,...], assessment_sha256:str).
  metrics always ordered observed,simulated,unknown, including empty cohorts;
  observations always ordered receipt ID ascending and only latest corrections.
  evidence_ids is the sorted unique full set of source, observation and previous
  review IDs referenced by this assessment. Reasons ordered due,trigger-rate,
  false-positive-rate,override-rate,impact (applicable members only). Threshold
  sample minimum uses that metric's known denominator (impact_known for impact).
- PracticeReviewReceipt(drawer_id:int, assessment:PracticeReviewAssessment,
  reviewed_on:str, reviewer:str, decision:str, rationale:str,
  next_review_due:str, receipt_sha256:str). reviewed_on equals assessment.as_of;
  assessment is retained exactly, including origin metrics/unknowns/source hashes.

event_id: 1..256 chars, exact primitive UTF-8, nonblank, no outer whitespace.
impact_unit: 1..64 chars with the same constraints. Reviewer: 1..256 and rationale:
1..8192 chars, exact primitive nonblank valid UTF-8, preserved verbatim including
outer whitespace. Evidence references: 1..64 unique exact ints in 1..2**63-1;
drawer/optional predecessor arguments have the same integer domain. Event dates
use the existing governance date validation; observed-origin future dates after
UTC today reject (simulated future dates may be recorded, but assess excludes
dates at/after its explicit as_of). Policy minimum_observations is an exact int
1..2**63-1; booleans cannot impersonate numeric IDs/counts/measurements. Impact
measurements accept exact int or float, excluding bool and nonfinite/overflowing
values. Missing pairs require impact_unit=None. Rate policy values have exact
int/float type excluding bool. All source/review/evidence hashes are lowercase
SHA256. A supplied forged result with altered counts/origin/hash cannot complete
a review; a locally constructed assessment is not authority without recomputation.

## Independent finish and budget

Independent tester gets thesis/issue/API/test parameters before runtime changes;
authors/freeze controls in r18-acceptance, outside builder write ownership. Retain
exact-base structural RED and assertion-level deliberately wrong control; preserve
all originals. Separate reviewer owns r18-redteam and probes input, correction,
scope, stale/concurrent/storage failure, source tamper and lifecycle boundaries.
At most two product repair rounds after frozen acceptance, >=25% verification
reserve. Local tests are isolated inert/synthetic hash embeddings, offline serial
bounded <=60 seconds, no models/render/stress/install. Full hosted existing checks,
unchanged 92% coverage floor, wheel/eval/mutation/platform and CodeQL must finish
on final exact head. Parent independently reviews after draft qualification.

No Cairntir MCP is callable in this environment; R18-PROGRESS.md and final evidence
substitute file checkpoints, without claiming a persistent-store memory save.
Keep full connected roadmap commitments and actual field outcome limits visible.
