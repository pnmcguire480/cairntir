"""Orchestration only: replay frozen assertions with ordinary pytest offline."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--label", required=True)
    parser.add_argument("--select", default="")
    parser.add_argument("--adapter", action="store_true")
    args = parser.parse_args()
    stem = HERE / args.label
    if stem.with_suffix(".log").exists() or stem.with_suffix(".json").exists():
        raise SystemExit("Refusing to overwrite original run evidence; choose a new label")
    frozen = json.loads((HERE / "freeze.json").read_text())
    for filename, expected in frozen["sha256"].items():
        actual = hashlib.sha256((HERE / filename).read_bytes()).hexdigest()
        if actual != expected:
            raise SystemExit(f"INVALID_FREEZE: {filename}: {actual} != {expected}")
    source = args.source.resolve()
    module = source / "src" / "cairntir" / "procedures.py"
    source_hash = hashlib.sha256(module.read_bytes()).hexdigest()
    with tempfile.TemporaryDirectory(prefix="r18-inert-") as scratch:
        env = dict(os.environ)
        env["PYTHONPATH"] = str(source / "src")
        env["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        for name in ("HOME", "USERPROFILE", "CAIRNTIR_HOME", "XDG_CACHE_HOME", "HF_HOME", "TRANSFORMERS_CACHE"):
            target = Path(scratch) / name.lower()
            target.mkdir()
            env[name] = str(target)
        for name in ("CAIRNTIR_DISABLE_AUTOREGISTER", "CAIRNTIR_DISABLE_UPDATE_CHECK", "HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE"):
            env[name] = "1"
        env.pop("CAIRNTIR_GRANT_FILE", None)
        testfile = "test_practice_reviews_independent.py" if args.adapter else "test_r18_controls.py"
        command = [sys.executable, "-m", "pytest", str(HERE / testfile), "-c", str(HERE / "pytest.ini"), "-vv", "--tb=short", "-p", "no:cacheprovider", "--basetemp", str(Path(scratch) / "pytest")]
        if args.select:
            command += ["-k", args.select]
        started = time.monotonic()
        try:
            result = subprocess.run(command, cwd=HERE, env=env, capture_output=True, text=True, timeout=60, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            code, output = result.returncode, result.stdout + result.stderr
        except subprocess.TimeoutExpired as exc:
            code, output = 124, f"BOUND_EXCEEDED: 60 seconds\n{exc.stdout!r}\n{exc.stderr!r}"
        duration = time.monotonic() - started
    stem.with_suffix(".log").write_text(output, encoding="utf-8")
    report = {"label": args.label, "source": str(source), "source_sha256": source_hash, "assertions_sha256": frozen["sha256"]["test_r18_controls.py"], "command": command, "selection": args.select or "all frozen controls", "returncode": code, "elapsed_seconds": round(duration, 3), "guard": "serial offline inert SQLite/HashEmbeddingProvider; isolated HOME/cache; <=60 sec", "log_sha256": hashlib.sha256(stem.with_suffix(".log").read_bytes()).hexdigest()}
    stem.with_suffix(".json").write_text(json.dumps(report, indent=2) + "\n")
    print(output)
    print(json.dumps(report, indent=2))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
