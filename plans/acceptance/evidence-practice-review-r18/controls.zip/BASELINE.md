# Original exact-base RED

Base 9e65c37c9a734f88d54935933047bda598e03146 / tree
5ee79667e3923dc30237249b4b65194fdf983995 was independently verified clean before
freeze. Baseline source SHA256 and assertion hashes are in freeze.json.

baseline-structural.log/json preserve an ordinary pytest run of the structure
control: 79 collected, one selected and directly failing because
PracticeObservation is absent; 78 deselected. This is the expected structural
preimplementation RED. It is not a reproduced R18 metric or lifecycle defect.
No downstream missing-method errors are presented as behavioral proof.

base-git-src.zip retains immutable original Git source bytes and
base-procedures-workspace.py retains exact Windows checkout bytes used for RED.
The public packet keeps originals; later passes never replace this evidence.
