"""Preserve immutable original source directly from frozen Git base."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / "cairntir-r18"
BASE = "9e65c37c9a734f88d54935933047bda598e03146"
frozen = json.loads((HERE / "freeze.json").read_text())
current = (ROOT / "src/cairntir/procedures.py").read_bytes()
assert hashlib.sha256(current).hexdigest() == frozen["base_procedures_sha256"], "base workspace changed before preservation"
(HERE / "base-procedures-workspace.py").write_bytes(current)
paths = subprocess.check_output(["git", "ls-tree", "-r", "--name-only", BASE, "src"], cwd=ROOT).decode().splitlines()
hashes = {}
with zipfile.ZipFile(HERE / "base-git-src.zip", "w", compression=zipfile.ZIP_STORED) as archive:
    for name in sorted(paths):
        data = subprocess.check_output(["git", "show", f"{BASE}:{name}"], cwd=ROOT)
        entry = zipfile.ZipInfo(name, date_time=(2026, 10, 3, 0, 0, 0))
        entry.create_system = 3
        entry.external_attr = 0o100644 << 16
        archive.writestr(entry, data)
        hashes[name] = hashlib.sha256(data).hexdigest()
identity = {"commit": BASE, "tree": frozen["base_tree"], "git_source_sha256": hashes, "workspace_procedures_sha256": frozen["base_procedures_sha256"], "git_source_zip_sha256": hashlib.sha256((HERE / "base-git-src.zip").read_bytes()).hexdigest(), "note": "Git source archive preserves repository blob bytes; workspace procedures copy separately preserves Windows checkout bytes used for RED"}
(HERE / "base-source-identity.json").write_text(json.dumps(identity, indent=2, sort_keys=True) + "\n")
print(identity["git_source_zip_sha256"])
