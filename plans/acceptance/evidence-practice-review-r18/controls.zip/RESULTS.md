# R18 independent acceptance results

PASS on final repaired candidate source SHA256
f3797a36fd610d26a895e0ed049cced0ecca2bbdcf0d80715da2fc5ea62d4342.
Seventy-nine frozen cases pass unchanged. No acceptance repair requested;
the separate red-team review prompted one product repair round for cross-window
acknowledgement and caller-owned receipt hash sequence detachment.

Original baseline: one selected direct STRUCTURAL_MISSING_API assertion failed
on exact base 9e65c37c9a734f88d54935933047bda598e03146 / tree
5ee79667e3923dc30237249b4b65194fdf983995; 78 cases deselected, 0.47 seconds.
This identifies the absent public API, not an R18 behavioral defect.

Initial candidate: candidate-round0.log/json retain 79 passes in 10.75 pytest
seconds, 11.109 seconds for the bounded process. All frozen hashes were checked
before execution. Assertions SHA256 remains
e3d16a18750af1094dcff48dcb5169a06d605f752ea57fcc9decb26846941fa5.
Original initial source SHA256 is
3ed29a65325a950d56ed55d8ae5d65adc562af5cb1b15443eb33119c852d2f03;
candidate-round0-source.zip/identity retain that source independently.

Final candidate: candidate-round1.log/json retain 79 passes in 4.73 pytest
seconds, 5.062 seconds for the process. candidate-source.zip and
candidate-round1-source.zip preserve identical exact tested final source bytes.

Meaningful isolated wrong-source control: wrong-metric.log/json retain one direct
assertion failure at test_r18_controls.py:232, obtained trigger_rate 0.0 versus
the independently worked expected 2/3; 78 deselected, 0.64 seconds. There were no
downstream exceptions or fixture errors. mutation.json retains exact append
patch and original/mutated source hashes. Runtime candidate was unchanged.
The same mutation was repeated on final source: wrong-metric-round1.log/json
retain the same one direct assertion failure in 0.63 seconds, without errors.
mutation-round0.json and mutation-round1.json keep both original patches/hashes;
mutation.json identifies the final-source replay recipe.

Ordinary pytest archive adapter: pytest-adapter-pass.log/json retain all 79
passes in 4.73 pytest seconds, 5.078 bounded process seconds on the same source.
It loads hash-pinned frozen original test bytes and exports the same fixtures
and tests. Adapter lint (repository test exemptions) and format passed.
Final source adapter replay also passes all 79 in 5.34 pytest seconds,
5.703 process seconds, retained in pytest-adapter-round1.log/json.

Coverage includes exact observed trigger/false-positive/override/impact values,
all missing/partial and zero denominators, origin separation, per-metric sample
minimum and strict thresholds, half-open calendar windows and corrections,
acknowledged evidence and future due dates, immutable attributed decisions,
late historical observations/version separation, replay/stale/failed-write
safety, copied/tampered records/source evidence, scoped denial, reopen,
legacy wire/registry preservation and unchanged promotion/operator execution.

Replay: unpack controls.zip; extract candidate-source.zip to an empty source
directory; use an existing authorized Python environment with repository
dependencies, without installing anything, then run:

```text
python run_controls.py --source <extracted-source> --label replay
python run_controls.py --source <extracted-source> --label adapter-replay --adapter
```

For the deliberately wrong result, append the exact mutation.json patch to the
copied procedures.py and select test_exact_metrics_origin_separation_and_strict_breaches.
Git base sources and exact Windows baseline procedure bytes are also preserved.
Orchestration is separate from frozen assertions. Reports name original source
paths and process commands as evidence; replay may use another authorized path.

These are tiny inert synthetic offline stores and HashEmbeddingProvider runs,
not actual field usage or a measured field quarter. Attributed observed origin
does not authenticate field truth. No live host/model, stress/concurrency-scale,
production migration or blanket damaged-store qualification is claimed.
Independent red-team, final-head hosted CI/CodeQL and parent review are
separate gates; this packet does not claim their result. No merge, install,
publication or live access change occurred.
Public packet preserves original bytes with fixed ZIP timestamps and excludes
databases/runtime homes/tokens.
