"""Create a deterministic byte-preserving public packet; no runtime homes/DBs."""
import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
FILES = ["CONTRACT.md", "R18-SCOPE.frozen.md", "test_r18_controls.py", "pytest.ini", "freeze.json", "run_controls.py", "package_controls.py", "preserve_base.py", "prepare_source_evidence.py", "test_practice_reviews_independent.py", "pytest-adapter-freeze.json", "pytest-adapter-pass.log", "pytest-adapter-pass.json", "BASELINE.md", "RESULTS.md", "baseline-structural.log", "baseline-structural.json", "base-source-identity.json", "base-git-src.zip", "base-procedures-workspace.py", "candidate-round0.log", "candidate-round0.json", "candidate-pass.log", "candidate-pass.json", "wrong-metric.log", "wrong-metric.json", "mutation.json", "candidate-source.zip", "candidate-source-identity.json"]
FILES += ["verify_packet.py"]


def main():
    frozen = json.loads((HERE / "freeze.json").read_text())
    for name, expected in frozen["sha256"].items():
        assert hashlib.sha256((HERE / name).read_bytes()).hexdigest() == expected, f"INVALID_FREEZE {name}"
    retained_rounds = [p.name for pattern in ("candidate-round*.log", "candidate-round*.json", "candidate-round*-source.zip", "candidate-round*-source-identity.json", "mutation-round*.json", "wrong-metric-round*.log", "wrong-metric-round*.json", "pytest-adapter-round*.log", "pytest-adapter-round*.json") for p in HERE.glob(pattern)]
    present = sorted(set(name for name in FILES + retained_rounds if (HERE / name).is_file()))
    manifest = {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest() for name in present}
    target = HERE / "controls.zip"
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_STORED) as archive:
        for name in sorted(present):
            entry = zipfile.ZipInfo(name, date_time=(2026, 10, 3, 0, 0, 0))
            entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, (HERE / name).read_bytes())
        entry = zipfile.ZipInfo("MANIFEST.json", date_time=(2026, 10, 3, 0, 0, 0))
        entry.create_system = 3
        entry.external_attr = 0o100644 << 16
        archive.writestr(entry, json.dumps(manifest, indent=2, sort_keys=True).encode() + b"\n")
    with zipfile.ZipFile(target) as archive:
        for name, expected in manifest.items():
            assert hashlib.sha256(archive.read(name)).hexdigest() == expected
    first = target.read_bytes()
    report = {"zip_sha256": hashlib.sha256(first).hexdigest(), "zip_bytes": len(first), "entry_count": len(present)+1, "original_bytes_verified": True, "fixed_timestamps": True, "manifest": manifest}
    (HERE / "public-packet-receipt.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "manifest"}, indent=2))


if __name__ == "__main__":
    main()
