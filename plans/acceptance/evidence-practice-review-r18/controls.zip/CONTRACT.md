# Frozen R18 independent acceptance

R18 outcomes: explicit source-backed observations and immutable review decisions;
honest known/unknown actual metrics; separate attributed observed/simulated/unknown
cohorts; explicit calendar and observed-evidence review; preservation of governed
and legacy procedure content/evaluation/promotion. Synthetic tests never supply
production field evidence or a measured quarter.

The exact preimplementation R18-SCOPE.md is copied in this packet as the agreed
public API contract. Controls call that public API with tiny synthetic SQLite
stores, explicitly registered inert holdout Outcomes and HashEmbeddingProvider.
SQL is used only for byte preservation, counting atomic rollback and deliberate
tamper injection. It is never used to fabricate accepted observations/procedures.

Frozen assertions: test_r18_controls.py. Replay: ordinary pytest through separate
run_controls.py and pytest.ini; local per-process timeout 60 seconds, serial and
offline. HOME/cache/CAIRNTIR_HOME are temporary and network/model constructors are
denied. No external state, package installs, models, live migrations or runtime
access changes. Freeze binds the exact scope, contract and assertions before any
procedures.py implementation change. Baseline RED is a structural missing-API
assertion, not an R18 behavioral defect reproduction.

Candidate runs must preserve all assertions. A separately copied source with one
deliberately wrong metric supplies assertion-level sensitivity evidence; its
failure is distinct from missing symbols, exceptions and downstream errors.
At most two repair rounds; parent reserves at least 25 percent for verification.
Public ZIP keeps original bytes and evidence with a fixed archive timestamp;
no databases, runtime homes or live tokens belong in the packet.
