"""Orchestration: preserve tested candidate and deliberately wrong source copy."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--mutation-name", default="wrong-metric-source")
    args = parser.parse_args()
    source = args.source.resolve()
    paths = sorted(path for path in (source / "src").rglob("*") if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc")
    hashes = {}
    with zipfile.ZipFile(HERE / "candidate-source.zip", "w", compression=zipfile.ZIP_STORED) as archive:
        for path in paths:
            relative = path.relative_to(source).as_posix()
            data = path.read_bytes()
            hashes[relative] = hashlib.sha256(data).hexdigest()
            entry = zipfile.ZipInfo(relative, date_time=(2026, 10, 3, 0, 0, 0))
            entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, data)
    identity = {"source": str(source), "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=source).decode().strip(), "tree": subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], cwd=source).decode().strip(), "status": subprocess.check_output(["git", "status", "--porcelain"], cwd=source).decode(), "file_sha256": hashes, "zip_sha256": hashlib.sha256((HERE / "candidate-source.zip").read_bytes()).hexdigest()}
    (HERE / "candidate-source-identity.json").write_text(json.dumps(identity, indent=2, sort_keys=True) + "\n")
    mutation = HERE / args.mutation_name
    if mutation.exists():
        raise SystemExit("Refusing to overwrite preserved source copy")
    shutil.copytree(source / "src", mutation / "src", ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    target = mutation / "src/cairntir/procedures.py"
    original = target.read_bytes()
    patch = b'''\n\n# Independent deliberately wrong source-copy control: report every known\n# observed trigger rate as zero, even when two of three events triggered.\n_r18_original_assess_review = ProcedureBook.assess_review\ndef _r18_wrong_trigger_metric(self, drawer_id, *, period_start, period_end, as_of, policy):\n    result = _r18_original_assess_review(self, drawer_id, period_start=period_start, period_end=period_end, as_of=as_of, policy=policy)\n    return replace(result, metrics=tuple(replace(m, trigger_rate=0.0) if m.origin == "observed" and m.trigger_rate is not None else m for m in result.metrics))\nProcedureBook.assess_review = _r18_wrong_trigger_metric\n'''
    target.write_bytes(original + patch)
    report = {"type": "isolated source-copy semantic mutation", "source_copy": str(mutation), "original_sha256": hashlib.sha256(original).hexdigest(), "mutated_sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "patch_utf8": patch.decode(), "selection": "test_exact_metrics_origin_separation_and_strict_breaches", "expected_direct_assertion": "observed trigger_rate == approx(2/3); mutation supplies 0.0", "candidate_original_preserved": hashlib.sha256((source / "src/cairntir/procedures.py").read_bytes()).hexdigest() == hashlib.sha256(original).hexdigest()}
    (HERE / "mutation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"snapshot": "candidate-source.zip", "mutation_source": str(mutation), "candidate_procedures_sha256": report["original_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
