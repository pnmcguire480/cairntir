"""Deterministic byte-preserving packet; excludes stores/source trees/runtime homes."""
import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parent
allowed = {".py", ".md", ".txt", ".json", ".log", ".diff", ".patch"}
excluded = {"PUBLIC-MANIFEST.json", "packet.sha256.json"}
files = {p.name: p.read_bytes() for p in root.iterdir()
    if p.is_file() and p.suffix in allowed and p.name not in excluded}
manifest = {name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    for name, data in sorted(files.items())}
manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode()
(root / "PUBLIC-MANIFEST.json").write_bytes(manifest_bytes)
files["PUBLIC-MANIFEST.json"] = manifest_bytes
def write(target):
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_STORED) as archive:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, (2026, 10, 3, 0, 0, 0))
            info.create_system = 0
            info.external_attr = 0
            info.compress_type = zipfile.ZIP_STORED
            archive.writestr(info, data)
first = root / "r18-redteam-public.zip"
second = root / "r18-redteam-public-rebuild.zip"
write(first)
write(second)
assert first.read_bytes() == second.read_bytes(), "non-deterministic packet"
with zipfile.ZipFile(first) as archive:
    assert archive.namelist() == sorted(files)
    for name, data in files.items():
        assert archive.read(name) == data, "changed bytes " + name
result = {"filename": first.name, "sha256": hashlib.sha256(first.read_bytes()).hexdigest(),
    "bytes": first.stat().st_size, "members": len(files), "byte_preserving": True,
    "rebuild_identical": True, "databases_or_runtime_homes": False}
(root / "packet.sha256.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
