# R18 independent adversarial review: PASS

Qualified runtime SHA256:
f3797a36fd610d26a895e0ed049cced0ecca2bbdcf0d80715da2fc5ea62d4342.
Final complete independent lane: 36 tests PASS in 2.576 seconds.
Normal pytest archive adapter: 36 tests PASS in 2.92 seconds on the same runtime.
One product repair round used; two introduced defects reproduced and repaired;
no material product defect remains from this review.

This is local synthetic review qualification of pinned source bytes. The checkout
HEAD/tree during these runs remained the exact base with uncommitted R18 source:
9e65c37c9a734f88d54935933047bda598e03146 /
5ee79667e3923dc30237249b4b65194fdf983995.
The parent must independently verify final commit/tree, hosted CI/CodeQL, and the
full delivery lane. This report does not claim a field quarter, authenticated
field origin, automatic policy execution, release, merge, installation, or live
adoption. Observed origin is an attributed classification in synthetic tests.

## Reproduced introduced defects and repair evidence

1. Acknowledgement was limited to the latest review's window. After reviewing a
   February bad event, completing a disjoint March window caused the unchanged
   February snapshot to re-alert. Frozen edge_probes.py reproduced
   reasons=('trigger-rate',), expected=(). All completed snapshots of the same
   content revision now contribute acknowledgement; latest completion still owns
   the effective deadline. The unchanged probe passes with visible metrics intact.
2. A locally constructed frozen PracticeObservationReceipt retained a caller list
   in evidence_sha256. Appending to that list mutated the receipt. Frozen
   sequence_probes.py reproduced list instead of tuple on exact reconstructed
   round0 source. The receipt now detaches the sequence as a tuple. The unchanged
   public-constructor probe passes.

Both fixes belong to product repair round 1. Original failures remain in
candidate-round0-edge.raw.log and candidate-round0-sequence.raw.log. No reviewer
edited runtime, frozen assertions, R17 packets, or independent R18 acceptance.

## Baseline and fixture provenance

Exact base source was archived into reviewer-owned storage; baseline runtime
SHA256 is 6d0ed499a601857aa41bd3d5fbba93b57cd6f391fa6409853423bc3e46974023.
Legacy wire bytes, copied-metadata authentication, and approval/staleness controls
passed. Missing R18 public API is structural RED, not a reproduced behavioral
regression. A separately frozen fresh corroborated approval-denial control passed.
An owned baseline-copy deliberate approval bypass failed at assertion level
(ProcedureError not raised); wrong-control.json and raw logs retain the result.

All initial probe files and freezes remain exact. Additive amendments preserve
their originals and document reasons:

- Fresh approval isolation separates approval denial from stale revision denial.
- Visibility fixture v2 includes the existing procedure-evaluations room.
- Fixture v2 commits direct synthetic SQL tampering before API calls, targets the
  actual stored record_sha256 envelope, and preserves existing MemoryStoreError
  for primitive entire-ledger shapes. Malformed JSON/object shape/hash remains
  ProcedureError; AccessDenied and operational store errors remain distinct.

The original round0 raw run has 32 methods, 28 successful methods, four affected
methods, one assertion failure and six error events including subtests. Earlier
interim summaries incorrectly counted error events as distinct failed methods;
the raw log is authoritative. Fixture-only corrections consumed no product repair.
Corrected 32-method lane passed on unchanged round0 source; the added cross-window
probe then reproduced the genuine product defect (34 of 35 passed).

Existing inherited whole-registry malformed-envelope exceptions were already
separately confirmed on exact R17/base and were not reopened. The new R18 tagged
ledger object schema, fingerprint, copied metadata, and source integrity were
adversarially checked. This is not a blanket damaged-store or hostile-SQL security
claim.

## Covered boundaries

The 36 final cases comprise three baseline controls and 33 R18 controls. They
cover primitive/UTF-8/date/ID/count bounds, bool-number aliasing, null and missing
denominators, mixed units and finite arithmetic, strict thresholds and metric
sample sizes, half-open dates, simulated/unknown isolation, exact replay and stale
corrections, source mutation, hidden source and hidden correction dependencies,
copied metadata, malformed raw ledger values/object shapes/hash fields, forged
assessment/result replay, stale evidence/lifecycle snapshots, ledger and after-add
write failures with rollback/clean retry, durable reopen/family history and late
historical observations, all three outcome decisions without lifecycle/approval
changes, tagged IDs refusing holdout promotion, opt-in queue filtering, global
snapshot acknowledgement and frozen public receipt sequence detachment.

Two tiny concurrent-writer tests use exactly two clients and one operation each:
one correction append wins, one stale writer rejects; one completion wins, one
stale writer rejects. No orphan record remains. Suites execute serially with an
outer process timeout of 60 seconds, dimension-32 HashEmbeddingProvider, isolated
temporary synthetic stores, and socket connections denied. No models, downloads,
installations, live store, credentials, access-settings change, public messaging,
or resource stress were used.

## Reconstructable identities and hosted orchestration

- Original freeze.json SHA256:
  7b4b70816b3565eb22c61d039bd02410b9520251aac69687cb74191f1bae154a.
- Final raw unittest log SHA256:
  1b5d95bd0feaf6facf546ce72005ed2b903264e793d76f7e6050cbeca2bae87b.
- Pytest adapter rehearsal raw log SHA256:
  38a506862f19c2397a0516525a12eb88e3987ff64b02c85b412fe501fc8715d4.
- Adapter source test_practice_review_redteam_archive_v2.py SHA256:
  8a33fbfc4d94695d3db18364d975c3f93ac437c75feb33de5a5d9e5b65c716bc.

Final local command: existing dev Python, qualify_final.py cairntir-r18
candidate-round1-final. Every freeze is checked; result JSON retains interpreter,
command, source/runtime hashes, base HEAD/tree, working status, and raw-log hash;
runtime diff reconstructs each candidate on the exact base.

Parent copies the v2 adapter as tests/unit/test_practice_review_redteam_archive.py
and the public zip as plans/acceptance/evidence-practice-review-r18/redteam-controls.zip.
The adapter pins every executed probe module's SHA256, rejects duplicate members,
requires all 36 cases, and executes exact unittest assertions/cleanups through
pytest parametrization. Repository-configured Ruff check/format passed. A changed
edge-probe archive member deliberately fails collection with an explicit frozen
probe integrity error; its raw negative-control output is preserved.

PUBLIC-MANIFEST.json inventories exact public packet bytes and SHA256. Zip members
are sorted, fixed timestamp, stored without recompression, and verified byte-for-byte.
Two independent rebuilds must match. The packet excludes all databases, extracted
source trees, and runtime homes. packet.sha256.json records the resulting hash.
Parent review and final exact-head hosted qualification remain outside this verdict.
