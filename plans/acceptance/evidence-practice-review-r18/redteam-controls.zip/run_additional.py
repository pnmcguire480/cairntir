"""Run additive probes with original freeze intact, preserving identities."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
source = Path(sys.argv[1]).resolve()
label = sys.argv[2]
baseline = len(sys.argv) > 3 and sys.argv[3] == "baseline"
for filename in ("freeze.json", "additive-freeze.json"):
    freeze = json.loads((root / filename).read_text())
    for name, digest in freeze["files"].items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name + " changed"
env = dict(os.environ, PYTHONPATH=str(source / "src") + os.pathsep + str(root), PYTHONDONTWRITEBYTECODE="1")
targets = ["additional_probes.ApprovalIsolation"] if baseline else ["additional_probes"]
result = subprocess.run([sys.executable, "-m", "unittest", "-v", *targets], cwd=root,
    env=env, capture_output=True, timeout=60, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
log = root / (label + ".raw.log")
log.write_bytes(result.stdout + result.stderr)
record = {"label": label, "source": str(source), "python": sys.executable, "exit_code": result.returncode,
    "runtime_sha256": hashlib.sha256((source / "src/cairntir/procedures.py").read_bytes()).hexdigest(),
    "raw_sha256": hashlib.sha256(log.read_bytes()).hexdigest(),
    "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "additive_freeze_sha256": hashlib.sha256((root / "additive-freeze.json").read_bytes()).hexdigest()}
if (source / ".git").exists():
    def git(*args):
        return subprocess.run(["git", "-C", str(source), *args], capture_output=True, check=True).stdout.decode().strip()
    record.update(head=git("rev-parse", "HEAD"), tree=git("rev-parse", "HEAD^{tree}"), status=git("status", "--porcelain"))
(root / (label + ".result.json")).write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
print(result.stderr.decode(errors="replace")[-18000:])
sys.exit(result.returncode)
