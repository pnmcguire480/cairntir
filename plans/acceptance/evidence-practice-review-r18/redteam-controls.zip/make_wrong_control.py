"""Reconstruct retained wrong approval control from the exact baseline archive."""
import hashlib
import shutil
from pathlib import Path

root = Path(__file__).resolve().parent
source = root / "baseline-source"
target = root / "wrong-control-source-rebuilt"
shutil.copytree(source, target)
runtime = target / "src/cairntir/procedures.py"
text = runtime.read_text()
assert text.count("if approved is not True:") == 1
runtime.write_text(text.replace("if approved is not True:", "if False:"))
print(hashlib.sha256(runtime.read_bytes()).hexdigest())
