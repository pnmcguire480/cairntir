"""Serial bounded runner with source identity and raw output retention."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
source = Path(sys.argv[1]).resolve()
label = sys.argv[2]
mode = sys.argv[3] if len(sys.argv) > 3 else "candidate"
freeze = json.loads((ROOT / "freeze.json").read_text())
for name, digest in freeze["files"].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name + " changed"
env = dict(os.environ)
env["PYTHONPATH"] = str(source / "src") + os.pathsep + str(ROOT)
env["PYTHONDONTWRITEBYTECODE"] = "1"
targets = ["probes.BaselineControls", "probes.R18Probes.test_api_present"] if mode == "baseline" else ["probes"]
result = subprocess.run([sys.executable, "-m", "unittest", "-v", *targets], cwd=ROOT,
    env=env, capture_output=True, timeout=60, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
(ROOT / (label + ".raw.log")).write_bytes(result.stdout + result.stderr)
def git(*args):
    return subprocess.run(["git", "-C", str(source), *args], capture_output=True, check=True).stdout.decode().strip()
identity = {"label": label, "mode": mode, "source": str(source), "python": sys.executable,
    "exit_code": result.returncode, "runtime_sha256": hashlib.sha256((source / "src/cairntir/procedures.py").read_bytes()).hexdigest(),
    "freeze_sha256": hashlib.sha256((ROOT / "freeze.json").read_bytes()).hexdigest(),
    "raw_sha256": hashlib.sha256((ROOT / (label + ".raw.log")).read_bytes()).hexdigest()}
if (source / ".git").exists():
    identity.update(head=git("rev-parse", "HEAD"), tree=git("rev-parse", "HEAD^{tree}"), status=git("status", "--porcelain"))
(ROOT / (label + ".result.json")).write_text(json.dumps(identity, indent=2) + "\n")
print(json.dumps(identity, indent=2))
print(result.stderr.decode(errors="replace")[-18000:])
sys.exit(result.returncode)
