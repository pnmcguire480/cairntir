# Additive freeze before candidate verdict

Original probes.py and freeze.json remain unchanged. Inspection of the newly
authored baseline approval check found its rejection path uses an already
superseded corroborated revision; this proves staleness, while the observed
callback proves one approval success. It does not isolate a fresh denied
approval. additional_probes.ApprovalIsolation supplies that separate control.
No baseline outcome was reclassified as a reproduced approval bypass.

Additional frozen probes cover two real synthetic-store clients interleaving
corrections and completions, write failure after a drawer is written, review
ledger shape/hash forgery, primitive boolean forgery even on replay, and ID
bounds. No product code or independent acceptance file was changed or read.
