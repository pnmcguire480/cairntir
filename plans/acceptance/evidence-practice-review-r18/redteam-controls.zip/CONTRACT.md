# Independent R18 adversarial review

Base: 9e65c37c9a734f88d54935933047bda598e03146,
tree 5ee79667e3923dc30237249b4b65194fdf983995.

Authority: ../R18-SCOPE.md, preserved byte-for-byte in scope.txt.
Public capability only: immutable source-bound observations and corrections;
observed, simulated, and unknown cohorts; explicit missingness in four metrics;
due and observed-evidence reasons; durable immutable review decisions with no
procedure lifecycle or approval mutation. Synthetic probes do not establish a
field quarter. At most two product repair rounds.

Probe authorship is independent of R18 builder and acceptance owner. No R18
acceptance assertions read. The inherited regular governance tests and initial
legacy procedure fixture interface were inspected for existing API mechanics;
this suite creates its own synthetic runner, examples, and expectations.

Runtime is owned by builder. Reviewer writes only this r18-redteam directory.
All stores are ephemeral under the platform temporary directory with dimension-32
HashEmbeddingProvider. Tests prohibit socket connections, are serial, and each
entire runner subprocess is bounded by 60 seconds. No installation, model,
credential, live store, access-settings change, or messaging is performed.

Baseline controls verify approval, metadata authentication, and exact legacy
wire bytes. Baseline missing R18 API is structural RED. Malformed inherited
whole-registry behavior was already separately established and is not reopened;
malformed newly tagged R18 ledger records remain in scope.

Expected result vocabulary: PASS, FAIL, INCONCLUSIVE. Freeze hashes remain exact;
fixture amendments, if necessary, are additive and separately retained. Candidate
verdict waits for parent's candidate-ready notification. Public packet excludes
databases, runtime homes, and extracted baseline source; original test/report/log
bytes are preserved, member names sorted, timestamps fixed.
