Original freezes, probes, and candidate-round0 results stay exact. No product repair consumed.

Round0 first run:32 methods;27 passes;1 failure (wrong stored hash field fixture assumption),6 error events. Synthetic SQL tamper fixture left transaction open (3 error events); primitive entire-ledger null/list/string emits existing typed MemoryStoreError (3 error subtests), explicitly preserved by contract. Original raw malformed JSON/object shape/hash expectations remain ProcedureError.

V2 commits synthetic SQL tampering; uses actual envelope record_sha256 hash for public review receipt hash verification; expects MemoryStoreError for primitive entire-ledger shapes only. Source assertions, lifecycle controls, immutable history, and expected metrics are unchanged. V2 copies plus runner are separately frozen and originals retained.
