"""Complete frozen independent review lane, <=60 seconds serial/offline."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
source = Path(sys.argv[1]).resolve()
label = sys.argv[2]
freezes = {}
for filename in ("freeze.json", "additive-freeze.json", "visibility-freeze.json", "visibility-v2-freeze.json", "reviewer-fixture-v2-freeze.json", "edge-freeze.json"):
    freezes[filename] = hashlib.sha256((root / filename).read_bytes()).hexdigest()
    for name, digest in json.loads((root / filename).read_text())["files"].items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name + " changed"
env = dict(os.environ, PYTHONPATH=str(source / "src") + os.pathsep + str(root), PYTHONDONTWRITEBYTECODE="1")
args = [sys.executable, "-m", "unittest", "-v", "probes_v2", "additional_probes_v2", "visibility_probes_v2", "edge_probes"]
runtime = source / "src/cairntir/procedures.py"
before = hashlib.sha256(runtime.read_bytes()).hexdigest()
result = subprocess.run(args, cwd=root, env=env, capture_output=True, timeout=60,
    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
after = hashlib.sha256(runtime.read_bytes()).hexdigest()
assert before == after, "candidate changed during run; qualification invalid"
log = root / (label + ".raw.log")
log.write_bytes(result.stdout + result.stderr)
record = {"label": label, "source": str(source), "python": sys.executable, "command": args,
    "exit_code": result.returncode, "runtime_sha256": before,
    "raw_sha256": hashlib.sha256(log.read_bytes()).hexdigest(), "freezes": freezes,
    "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
def git(*args):
    return subprocess.run(["git", "-C", str(source), *args], capture_output=True, check=True).stdout
record.update(head=git("rev-parse", "HEAD").decode().strip(), tree=git("rev-parse", "HEAD^{tree}").decode().strip(),
    status=git("status", "--porcelain").decode().strip())
(root / (label + ".runtime.diff")).write_bytes(git("diff", "HEAD", "--", "src/cairntir/procedures.py"))
(root / (label + ".result.json")).write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
print(result.stderr.decode(errors="replace")[-28000:])
sys.exit(result.returncode)
