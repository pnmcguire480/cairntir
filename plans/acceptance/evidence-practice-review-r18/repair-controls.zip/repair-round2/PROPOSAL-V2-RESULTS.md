# Latest scratch proposal v2 independent acceptance

PASS: final combined 111 unchanged assertions (original 79 + independently
frozen 32 through supplemental ordinary-pytest archive adapter) pass in
7.24 pytest seconds / 7.594 bounded process seconds. Exact final scratch
procedures SHA256 e20d3dfcbffa56fae4eaeccf922c982ef50ff37011c38b37f74c1b8938855fd7;
shared access adapter SHA256 8202fe58fb4a449d3bb751e8698e029b4ff1fb032ed0501cb7656fd91a49538a.
proposal-v2-final-pass.log/json retain complete result, source identities and
command. Final log SHA256 is
de5370fb2bfb64d571ee753500eb6b75dabf85ac98d2d72a529ea3c0b91f0e5c.

This supplements the preserved earlier scratch proposal packet
repair-controls.zip SHA256 6530a831a920033afb58815b9a9babb64d8b41beec9564d699a1a6c119889aa1.
That entire original packet, logs, source ZIP and source identity remain
unchanged and are embedded byte-for-byte as repair-round2/repair-controls.zip.
The original 79 packet remains unchanged SHA256
22ad7c49055f6783e8d4783c23b93d7188dbc4c27fac58d03b6aaad73072ed9f.
Frozen supplemental assertion SHA256 remains
94738fae1dd2533cfad1925f66ebb58488bd6ce8f6f0500220f30fbf0ad80ed6;
original assertions remain e3d16a18750af1094dcff48dcb5169a06d605f752ea57fcc9decb26846941fa5.

The independently reviewed same-round proposal added a final completeness
proof after collection to catch grant narrowing during a call. Separate
red-team controls cover that newly identified race; these existing 32 controls
are not retrospectively claimed to detect it. On the intermediate 5a9 source,
32 direct controls passed in 2.95 seconds, original 79 in 16.17 seconds and
32-case supplemental adapter in 2.70 seconds. All logs and that exact source
snapshot remain alongside final evidence. The final source differs from 5a9
only by the parent-reported lint-only try/else return placement.

No assertion edits, expectation changes, prior-result overwrites, grants to
live stores, models, network calls, PR edits, install, merge or deployment
occurred. Supplemental scoped tests use actual ScopedStore with inert _grant
loader replacement and no persisted grants. Original 79 replay retains its
pre-existing authorized synthetic grant fixtures. All processes were serial,
offline, temporary SQLite/HashEmbeddingProvider and under 60 seconds.

Public proposal-v2-controls.zip keeps deterministic fixed timestamps, complete
source snapshots and originals; no databases or runtime homes. The ordinary
pytest adapter is unchanged and compatible with the new archive shape. For
hosted use, copy proposal-v2-controls.zip as
plans/acceptance/evidence-practice-review-r18/repair-controls.zip and preserve
original controls.zip alongside it. Copy unchanged adapter to tests/unit.

Replay after unpacking: extract proposal-v2-final-source.zip from repair-round2
to an empty source directory; extract test_r18_controls.py from embedded
controls.zip to packet root. With an existing authorized dependency environment:

```text
python repair-round2/run_final_proposal.py --source <extracted-source> --label replay-final
```

The actual qualified PR head 23c642 remains unchanged and blocked pending
shared-file coordination, applying the reviewed proposal, fresh exact-head
hosted CI/CodeQL and parent review. These are scratch-only source results;
synthetic acceptance is not a measured field quarter or actual field usage.
