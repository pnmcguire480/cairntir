"""One bounded combined111 replay after final scratch lint-only source movement."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--source", type=Path, required=True)
parser.add_argument("--label", default="proposal-v2-final-pass")
args = parser.parse_args()
source = args.source.resolve()
stem = HERE / args.label
assert not stem.with_suffix(".log").exists() and not stem.with_suffix(".json").exists()
assert hashlib.sha256((HERE / "test_r18_scope_repair.py").read_bytes()).hexdigest() == "94738fae1dd2533cfad1925f66ebb58488bd6ce8f6f0500220f30fbf0ad80ed6"
assert hashlib.sha256((HERE.parent / "test_r18_controls.py").read_bytes()).hexdigest() == "e3d16a18750af1094dcff48dcb5169a06d605f752ea57fcc9decb26846941fa5"
procedures = hashlib.sha256((source / "src/cairntir/procedures.py").read_bytes()).hexdigest()
access = hashlib.sha256((source / "src/cairntir/access.py").read_bytes()).hexdigest()
assert procedures == "e20d3dfcbffa56fae4eaeccf922c982ef50ff37011c38b37f74c1b8938855fd7"
assert access == "8202fe58fb4a449d3bb751e8698e029b4ff1fb032ed0501cb7656fd91a49538a"
with tempfile.TemporaryDirectory(prefix="r18-final-inert-") as scratch:
    env = dict(os.environ)
    env.update(PYTHONPATH=str(source / "src"), PYTEST_DISABLE_PLUGIN_AUTOLOAD="1", PYTHONDONTWRITEBYTECODE="1", CAIRNTIR_DISABLE_AUTOREGISTER="1", CAIRNTIR_DISABLE_UPDATE_CHECK="1", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1")
    env.pop("CAIRNTIR_GRANT_FILE", None)
    for name in ("HOME", "USERPROFILE", "CAIRNTIR_HOME", "XDG_CACHE_HOME", "HF_HOME", "TRANSFORMERS_CACHE"):
        target = Path(scratch) / name.lower()
        target.mkdir()
        env[name] = str(target)
    command = [sys.executable, "-m", "pytest", str(HERE.parent / "test_r18_controls.py"), str(HERE / "test_practice_scope_independent.py"), "-c", str(HERE.parent / "pytest.ini"), "-vv", "--tb=short", "-p", "no:cacheprovider", "--basetemp", str(Path(scratch) / "pytest")]
    started = time.monotonic()
    result = subprocess.run(command, cwd=HERE, env=env, capture_output=True, text=True, timeout=60, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    elapsed = time.monotonic() - started
output = result.stdout + result.stderr
stem.with_suffix(".log").write_text(output, encoding="utf-8")
report = {"source": str(source), "procedures_sha256": procedures, "access_sha256": access, "expected_cases": 111, "command": command, "returncode": result.returncode, "elapsed_seconds": round(elapsed, 3), "log_sha256": hashlib.sha256(stem.with_suffix(".log").read_bytes()).hexdigest(), "original79_unchanged": True, "supplemental32_hash_pinned_adapter": True}
stem.with_suffix(".json").write_text(json.dumps(report, indent=2) + "\n")
print(output)
print(json.dumps(report, indent=2))
raise SystemExit(result.returncode)
