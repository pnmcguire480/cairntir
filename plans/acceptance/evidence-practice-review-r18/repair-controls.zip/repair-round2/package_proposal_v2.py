"""Additional deterministic packet retaining prior proposal bytes untouched."""
import hashlib
import io
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
prior = (HERE / "repair-controls.zip").read_bytes()
original = (HERE.parent / "controls.zip").read_bytes()
assert hashlib.sha256(prior).hexdigest() == "6530a831a920033afb58815b9a9babb64d8b41beec9564d699a1a6c119889aa1"
assert hashlib.sha256(original).hexdigest() == "22ad7c49055f6783e8d4783c23b93d7188dbc4c27fac58d03b6aaad73072ed9f"
frozen = json.loads((HERE / "freeze.json").read_text())
for name, expected in frozen["sha256"].items():
    assert hashlib.sha256((HERE / name).read_bytes()).hexdigest() == expected
run = json.loads((HERE / "proposal-v2-final-pass.json").read_text())
snapshot = json.loads((HERE / "proposal-v2-final-source-identity.json").read_text())
assert run["returncode"] == 0
assert run["procedures_sha256"] == snapshot["file_sha256"]["src/cairntir/procedures.py"]
assert run["access_sha256"] == snapshot["file_sha256"]["src/cairntir/access.py"]
names = ["test_r18_scope_repair.py", "CONTRACT.md", "freeze.json", "test_practice_scope_independent.py", "adapter-freeze.json", "run_repair_controls.py", "run_final_proposal.py", "snapshot_proposal_v2.py", "package_proposal_v2.py", "PROPOSAL-V2-RESULTS.md", "proposal-v2-32-pass.log", "proposal-v2-32-pass.json", "proposal-v2-79-pass.log", "proposal-v2-79-pass.json", "proposal-v2-adapter-pass.log", "proposal-v2-adapter-pass.json", "proposal-v2-final-pass.log", "proposal-v2-final-pass.json", "proposal-v2-interim-source.zip", "proposal-v2-interim-source-identity.json", "proposal-v2-final-source.zip", "proposal-v2-final-source-identity.json"]
contents = {f"repair-round2/{name}": (HERE / name).read_bytes() for name in names}
contents["repair-round2/repair-controls.zip"] = prior
contents["controls.zip"] = original
contents["pytest.ini"] = (HERE.parent / "pytest.ini").read_bytes()
manifest = {name: hashlib.sha256(data).hexdigest() for name, data in contents.items()}
contents["MANIFEST.json"] = json.dumps(manifest, indent=2, sort_keys=True).encode() + b"\n"
target = HERE / "proposal-v2-controls.zip"


def build():
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_STORED) as archive:
        for name, data in sorted(contents.items()):
            entry = zipfile.ZipInfo(name, date_time=(2026, 10, 3, 0, 0, 0))
            entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, data)
    return target.read_bytes()


first = build()
second = build()
assert first == second
with zipfile.ZipFile(io.BytesIO(second)) as archive:
    for name, data in contents.items():
        assert archive.read(name) == data
        assert not name.endswith((".db", ".db-wal", ".db-shm", ".sqlite", ".sqlite3"))
        if name.endswith("-source.zip"):
            with zipfile.ZipFile(io.BytesIO(data)) as source_zip:
                assert all(key.startswith("src/") and not key.endswith((".db", ".pyc", ".sqlite")) for key in source_zip.namelist())
report = {"zip_sha256": hashlib.sha256(second).hexdigest(), "zip_bytes": len(second), "entry_count": len(contents), "two_builds_byte_identical": True, "original_bytes_verified": True, "prior_packet_unchanged_sha256": hashlib.sha256(prior).hexdigest(), "original_packet_unchanged_sha256": hashlib.sha256(original).hexdigest(), "procedures_sha256": run["procedures_sha256"], "access_sha256": run["access_sha256"], "final_combined_cases": 111}
(HERE / "proposal-v2-packet-receipt.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
