"""Bounded offline orchestration; frozen additive assertions remain separate."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--source", type=Path, required=True)
parser.add_argument("--label", required=True)
parser.add_argument("--original", action="store_true")
parser.add_argument("--adapter", action="store_true")
args = parser.parse_args()
receipt = json.loads((HERE / "freeze.json").read_text())
for name, expected in receipt["sha256"].items():
    assert hashlib.sha256((HERE / name).read_bytes()).hexdigest() == expected
stem = HERE / args.label
assert not stem.with_suffix(".json").exists() and not stem.with_suffix(".log").exists()
source = args.source.resolve()
source_sha256 = hashlib.sha256((source / "src/cairntir/procedures.py").read_bytes()).hexdigest()
testfile = HERE.parent / "test_r18_controls.py" if args.original else HERE / "test_practice_scope_independent.py" if args.adapter else HERE / "test_r18_scope_repair.py"
assertion_hash = "e3d16a18750af1094dcff48dcb5169a06d605f752ea57fcc9decb26846941fa5" if args.original else receipt["sha256"]["test_r18_scope_repair.py"]
if not args.adapter:
    assert hashlib.sha256(testfile.read_bytes()).hexdigest() == assertion_hash
with tempfile.TemporaryDirectory(prefix="r18-repair-inert-") as scratch:
    env = dict(os.environ)
    env.update(PYTHONPATH=str(source / "src"), PYTEST_DISABLE_PLUGIN_AUTOLOAD="1", PYTHONDONTWRITEBYTECODE="1", CAIRNTIR_DISABLE_AUTOREGISTER="1", CAIRNTIR_DISABLE_UPDATE_CHECK="1", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1")
    env.pop("CAIRNTIR_GRANT_FILE", None)
    for name in ("HOME", "USERPROFILE", "CAIRNTIR_HOME", "XDG_CACHE_HOME", "HF_HOME", "TRANSFORMERS_CACHE"):
        target = Path(scratch) / name.lower()
        target.mkdir()
        env[name] = str(target)
    command = [sys.executable, "-m", "pytest", str(testfile), "-c", str(HERE.parent / "pytest.ini"), "-vv", "--tb=short", "-p", "no:cacheprovider", "--basetemp", str(Path(scratch) / "pytest")]
    started = time.monotonic()
    result = subprocess.run(command, cwd=HERE, env=env, capture_output=True, text=True, timeout=60, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    elapsed = time.monotonic() - started
output = result.stdout + result.stderr
stem.with_suffix(".log").write_text(output, encoding="utf-8")
report = {"source": str(source), "source_sha256": source_sha256, "assertions_sha256": assertion_hash, "command": command, "returncode": result.returncode, "elapsed_seconds": round(elapsed, 3), "log_sha256": hashlib.sha256(stem.with_suffix(".log").read_bytes()).hexdigest(), "scope_fixture": "actual ScopedStore; inert _grant only; no persisted grants" if not args.original else "original unchanged79 compatibility controls"}
stem.with_suffix(".json").write_text(json.dumps(report, indent=2) + "\n")
print(output)
print(json.dumps(report, indent=2))
raise SystemExit(result.returncode)
