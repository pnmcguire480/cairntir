"""Preserve an additional exact scratch source without replacing prior evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--source", type=Path, required=True)
parser.add_argument("--label", required=True)
args = parser.parse_args()
target = HERE / f"{args.label}-source.zip"
identity = HERE / f"{args.label}-source-identity.json"
assert not target.exists() and not identity.exists()
source = args.source.resolve()
hashes = {}
with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_STORED) as archive:
    for path in sorted((source / "src").rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        name = path.relative_to(source).as_posix()
        data = path.read_bytes()
        hashes[name] = hashlib.sha256(data).hexdigest()
        entry = zipfile.ZipInfo(name, date_time=(2026, 10, 3, 0, 0, 0))
        entry.create_system = 3
        entry.external_attr = 0o100644 << 16
        archive.writestr(entry, data)
report = {"source": str(source), "file_sha256": hashes, "zip_sha256": hashlib.sha256(target.read_bytes()).hexdigest()}
identity.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
print(json.dumps({"procedures_sha256": hashes["src/cairntir/procedures.py"], "access_sha256": hashes["src/cairntir/access.py"]}, indent=2))
