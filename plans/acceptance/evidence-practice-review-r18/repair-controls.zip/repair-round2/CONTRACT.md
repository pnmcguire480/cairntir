# Additive repair round 2 contract

Original R18 acceptance files, 79 assertions, freeze and ZIP are immutable.
These independently frozen regressions address parent-review P1: restricted ID
visibility must not be presented as complete family history, metrics, deadlines
or active-practice queue. Visibility includes lifecycle/current revision records.
The conservative procedures-only contract requires a live read capability and
an unrestricted entire requested-wing scope for R18 histories, assessment and
queue. Finite ID grants remain unprovable even when all current IDs are present;
they fail AccessDenied. Optional narrower room support is outside these controls.
Broad-wing authorization does not bypass individual authenticated dependencies;
portable/registry closure withholding must still surface AccessDenied. Failures
preserve original rows and do not disclose hidden record contents.

Fixtures execute actual ScopedStore; only its _grant loader returns inert scopes.
No grant is created, changed or persisted. Frozen original fixture bytes are
SHA256-pinned inside the unchanged original public archive. All stores are inert
SQLite/HashEmbeddingProvider, offline and temporary, with no live runtime access.

Transaction contract: when the caller owns the outer store transaction, returned
R18 receipts are provisional until that caller successfully commits. They are
invisible to an independent connection before commit, disappear on outer rollback,
and authenticate after committed reopen. This is standard transaction composition,
not a demand to reject nested new writes. When R18 owns the transaction, denied
commit surfaces MemoryStoreError, returns no receipt, rolls back and allows retry.

Baseline behavioral RED is retained on qualified commit 23c642f4731791894fc5350fa7f6b770d9c2997c
before procedures.py repair. Assertions freeze before runtime changes. This is
the authorized second/last product repair round; at least 25 percent verification
reserve remains parent-owned. Public packet is additive and deterministic, with
original scope-failure evidence and final candidate evidence kept separately.
