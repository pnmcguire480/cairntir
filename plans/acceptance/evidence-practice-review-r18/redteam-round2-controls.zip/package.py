"""Byte-preserving deterministic additive packet, original packet never changed."""
import hashlib
import json
import sys
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parent
label = sys.argv[1]
files = {p.name: p.read_bytes() for p in root.iterdir() if p.is_file()
    and p.suffix in {".py", ".md", ".json", ".log", ".diff"}
    and not p.name.endswith(".packet.json") and not p.name.endswith(".manifest.json")}
manifest = {name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    for name, data in sorted(files.items())}
manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode()
(root / (label + ".manifest.json")).write_bytes(manifest_bytes)
files["PUBLIC-MANIFEST.json"] = manifest_bytes
def write(target):
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_STORED) as archive:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, (2026, 10, 3, 0, 0, 0))
            info.create_system = 0
            info.external_attr = 0
            archive.writestr(info, data)
packet = root / (label + ".zip")
rebuild = root / (label + ".rebuild.zip")
if packet.exists() or rebuild.exists():
    raise AssertionError("do not overwrite packet")
write(packet)
write(rebuild)
if packet.read_bytes() != rebuild.read_bytes():
    raise AssertionError("non-deterministic rebuild")
with zipfile.ZipFile(packet) as archive:
    for name, data in files.items():
        if archive.read(name) != data:
            raise AssertionError("changed member bytes")
result = {"filename": packet.name, "sha256": hashlib.sha256(packet.read_bytes()).hexdigest(),
    "bytes": packet.stat().st_size, "members": len(files), "rebuild_identical": True,
    "byte_preserving": True, "databases_or_runtime_homes": False}
(root / (label + ".packet.json")).write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
