# Additive closure proof and shared adapter coordination

Whole-wing grants alone do not prove recursive visibility. A same-wing source
can supersede a foreign-wing ancestor; ScopedStore recursively withholds that
source and a newer procedure transition referencing it. R18 can then aggregate
an old promoted revision as current. Frozen closure_probes.py reproduced this
on the unchanged exact23c642 source. The original16 completeness tests and this
original1 closure probe stay unchanged.

Parent proposes a read-only adapter-owned complete-wing guard. It requires an
existing unrestricted read scope for the requested wing, then verifies no owned
wing drawer is missing from the adapter's authoritative recursive visible set.
Any incompleteness raises existing generic AccessDenied without hidden identities,
counts or content. Procedures calls the proof without owner unwrap, raw SQL,
grant widening or new capability. Shared-file coordination is required before
branch application; the current branch stays unchanged pending that coordination.

New additive closure tests separately check the hidden-current queue, unrelated
hidden own-wing row, hidden usage-source closure, authorized foreign dependency
graph success, and read-only broad grant success. All freeze before proposal
runtime execution. No prior failure expectation is weakened or replaced.
