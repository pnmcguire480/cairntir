"""Complete original36 plus unchanged additive22, bounded and byte-identified."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
source = Path(sys.argv[1]).resolve()
label = sys.argv[2]
mode = sys.argv[3] if len(sys.argv) > 3 else "complete"
checks = [(root, name) for name in ("freeze.json", "closure-freeze.json", "closure-additional-freeze.json")]
checks.extend((root.parent, name) for name in ("freeze.json", "additive-freeze.json",
    "visibility-v2-freeze.json", "reviewer-fixture-v2-freeze.json", "edge-freeze.json", "sequence-freeze.json"))
for folder, name in checks:
    for filename, digest in json.loads((folder / name).read_text())["files"].items():
        if hashlib.sha256((folder / filename).read_bytes()).hexdigest() != digest:
            raise AssertionError("frozen artifact changed: " + filename)
if hashlib.sha256((root.parent / "r18-redteam-public.zip").read_bytes()).hexdigest() != "4e15f59541920d47a2f35b274254fee56af904c674c23603d942e0c3f1844f50":
    raise AssertionError("original public packet changed")
targets = ["completeness_probes", "closure_probes.RecursiveClosure.test_foreign_ancestor_cannot_hide_newer_transition_under_broad_requested_wing", "closure_additional.ClosureAdditional"]
if mode == "additional":
    targets = ["closure_additional.ClosureAdditional"]
elif mode == "complete":
    targets = ["probes_v2", "additional_probes_v2", "visibility_probes_v2", "edge_probes", "sequence_probes", *targets]
env = dict(os.environ, PYTHONPATH=os.pathsep.join([str(source / "src"), str(root.parent), str(root)]),
    PYTHONDONTWRITEBYTECODE="1")
identities = {name: hashlib.sha256((source / "src/cairntir" / name).read_bytes()).hexdigest()
    for name in ("procedures.py", "access.py", "memory/store.py")}
command = [sys.executable, "-m", "unittest", "-v", *targets]
result = subprocess.run(command, cwd=root, env=env, capture_output=True, timeout=60,
    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
for name, digest in identities.items():
    if hashlib.sha256((source / "src/cairntir" / name).read_bytes()).hexdigest() != digest:
        raise AssertionError("candidate changed during run")
raw = result.stdout + result.stderr
log = root / (label + ".raw.log")
if log.exists():
    raise AssertionError("do not overwrite raw logs")
log.write_bytes(raw)
record = {"source": str(source), "source_sha256": identities, "command": command,
    "exit_code": result.returncode, "raw_sha256": hashlib.sha256(raw).hexdigest(),
    "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "original_packet_preserved": True}
if (source / ".git").exists():
    def git(*args):
        return subprocess.run(["git", "-C", str(source), *args], capture_output=True, check=True).stdout
    record.update(head=git("rev-parse", "HEAD").decode().strip(), tree=git("rev-parse", "HEAD^{tree}").decode().strip(),
        status=git("status", "--porcelain").decode().strip())
    (root / (label + ".runtime.diff")).write_bytes(git("diff", "HEAD", "--", "src/cairntir/procedures.py", "src/cairntir/access.py"))
(root / (label + ".result.json")).write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
print(raw.decode(errors="replace")[-30000:])
sys.exit(result.returncode)
