# R18 round2 independent review: proposed repair PASS; current PR blocked

Final scratch proposal passes all61 independent frozen controls in7.305seconds.
Normal pytest supplemental archive adapter passes all25 additive cases in2.52seconds.
No remaining material defect identified in the final scratch proposal.

Qualified proposed source bytes:

| File | SHA256 |
| --- | --- |
| procedures.py | e20d3dfcbffa56fae4eaeccf922c982ef50ff37011c38b37f74c1b8938855fd7 |
| access.py | 8202fe58fb4a449d3bb751e8698e029b4ff1fb032ed0501cb7656fd91a49538a |
| memory/store.py, unchanged | 74bca7fd7add465ff443931a635a594c5a629fc029fc5e30a77d277fbfca05d0 |

The actual PR remains unchanged at head23c642f4731791894fc5350fa7f6b770d9c2997c,
treef5f31e2e008ccacf9b329bfd2a68502f7d54dc0c, procedures runtimef3797a36fd610d26a895e0ed049cced0ecca2bbdcf0d80715da2fc5ea62d4342.
That current head is behaviorally RED for the reproduced P1 scope-completeness
defect. Applying the shared access-adapter repair requires parent coordination
because access.py lies outside the R18 procedures-only lane. Scratch PASS is not
qualification of that unchanged PR, a final commit/tree, hosted CI/CodeQL, or adoption.

## Original review gap and reproduced failures

The original review tested hidden evidence dependencies but missed omitted ledger
rows. Parent independent review found the gap. Original review artifacts, report,
all frozen tests and original zip remain byte-for-byte unchanged. The earlier
original36 local PASS cannot substitute for these newly reproduced boundaries.

An ID-restricted scoped client could omit an observation and change a50% trigger
rate to100%, omit a latest correction and restore superseded metrics, or omit a
completed review and restore an old deadline. It could also omit a newer procedure
transition and treat an older promoted revision as current. A partial empty queue
could return success. Current finite IDs or unions of limited scopes cannot prove
complete evidence, even if all currently known rows happen to be listed.

Frozen initial16 controls reproduced13 assertion failures across9 affected methods
on exact23c642 in1.814seconds;7 methods passed. Raw baseline-red.raw.log SHA256:
0dfb2cb2ff919cf578578f8dc204caaf155429126f9c004a5f191c1ca650ef81.
No expectations were weakened or rewritten.

Source review then found requested-wing broad scope alone also insufficient.
A same-wing source can supersede a foreign-wing ancestor, so recursive visibility
withholds the source and a newer procedure transition referring to it. The scoped
old revision then looks current. The frozen closure probe reproduced this on exact
archived23c642. Additional controls separately prove hidden-current queue denial,
unrelated hidden own-wing row denial, hidden source lineage denial, successful
authorized foreign dependency graphs, and read-only broad-grant success.

The first scratch guard repaired these cases and passed58 controls. Additional
frozen grant-recheck tests then proved two missing return checks: an empty queue
or history could succeed after the scope narrowed following initial proof. The
guard's own internal grant recheck passed; the two return-path tests failed before
their repairs. Their unchanged assertions now pass. This was tightening the same
round2 scratch proposal before coordination, not a third product repair round.

## Concrete repair and independent source review

ScopedStore owns a read-only completeness proof. It requires an existing
unrestricted whole-wing read scope and compares every owned wing drawer identity
with the adapter's existing recursive visible closure. Missing coverage/closure
raises existing generic AccessDenied without revealing hidden IDs, counts or
content. Grant identity is rechecked after proof. The SQL and owner access remain
inside the access adapter; Procedures does not unwrap the owner, query raw SQL,
widen grants or add a capability. Direct immutable getters keep ordinary scoped
per-reference authorization. Unsupported scoped adapters fail closed.

Proof runs at history/aggregate/queue/write freshness boundaries and before
successful returns, including empty queue and replay returns. Ordinary owner and
fully authorized closed graphs remain supported. Limited ID/room unions fail
closed even if current finite coverage is complete; unrelated requested-wing
drawers withheld by recursive closure also prevent a completeness claim.

Caller-owned outer transaction receipts are documented as provisional until the
caller commits. The retained additive control rolls observation and completion
back in outer transactions and confirms exact clean retries, alongside unchanged
original failed-registration/after-add rollback and concurrent writer controls.
No new outer-transaction guard or implicit durability acknowledgement was added.

The final lint-only try/else movement was followed by a complete61 replay. The
final source review identified no remaining material defect under these boundaries.
Existing inherited whole-registry raw-envelope exceptions remain separately
classified; no blanket damaged-store guarantee or unrelated store repair is claimed.

## Frozen inventory, raw outputs and orchestration

All61 comprise unchanged original36 plus additive25: initial completeness16,
the exact original closure method1, additional closure5, and grant-recheck3.
The original16 and every subsequent probe freeze were captured before the relevant
repair/proposal execution. No failed assertion was replaced. Old orchestration
and proposal archives remain retained. One initial module run auto-collected
imported CompletenessBoundary16 in addition to new closure5; its raw21 output is
preserved and final orchestration selects explicit classes to execute unique cases.

Final independent raw log SHA256:
a559e938ba0c605ce282bed435d2d2847e8e4a0b0a765935ecc284d7bae236f7.
Final normal pytest adapter raw log SHA256:
13dd50a4217b4913fc0607360ab199f1cc44de2f0cc4833d6bb01b999c7c567d.
Runner run_final_v3.py SHA256:
92badcb58f79163f0384e2606dde231308274127382e8fe97706cac66af0dd4b.
Adapter test_practice_review_redteam_round2_archive_v2.py SHA256:
520d96be9755b6ae07ac5fdcc138f97184ef08db4f9c417d76d6d5900db77ae0.

Result JSON records source/interpreter/command/source hashes, base HEAD/tree and
working diff. All proposal runtime diffs and raw failures are retained. The new
pytest adapter pins the original fixture from original redteam-controls.zip and
every new probe module from supplemental redteam-round2-controls.zip, rejects
duplicate members, requires all25 cases, and executes exact unittest assertions
and cleanup via pytest. Ruff check/format passed before adapter freeze.

All stores are tiny synthetic HashEmbeddingProvider fixtures. The new scoped tests
use real ScopedStore machinery with only its grant-loader replaced by inert
in-memory scopes; no persisted grant, settings change, private store, credential,
model, installation, live runtime or public message is involved. Tests are serial
with a60second process bound. Synthetic observations establish no real field quarter.

Original public packet SHA256 remains:
4e15f59541920d47a2f35b274254fee56af904c674c23603d942e0c3f1844f50.
Prior supplemental proposal-v2 packet remains:
e38804b1c16e16fb9480b31864f60d8f61b47d9bf371f85bad34651c68abbea6.
The final additive packet is byte-preserving, sorted, fixed timestamp and verified
against an identical rebuild; databases, extracted source trees and runtime homes
are excluded. Its packet JSON records the final hash. Earlier status/source-review
documents remain historical; this report gives the final proposed-source verdict.

Remaining blocker: shared access-file coordination, application of these exact
qualified bytes to the PR, final exact-head checks, and parent independent review.
This is the second and last authorized product repair round; no silent extra round
or current-PR success is asserted.
