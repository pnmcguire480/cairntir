# Scratch round2 source review

Reviewed source procedures.py SHA256
5a9af4f6f5f8c983ce61ad5fb4b015cbd4715a3b23bea6cf430e331cdad1ec8d,
access.py SHA256
8202fe58fb4a449d3bb751e8698e029b4ff1fb032ed0501cb7656fd91a49538a.
Original36 plus frozen additive25 = 61 PASS in10.697seconds. Raw log SHA256
a96cfcf843502174e7e3b6e91ce6c3d21be5000feb75b92df2c3eb4f75f2dc01.

The adapter proof requires an existing unrestricted read scope for the requested
wing, compares all owned wing drawer IDs against recursive visible closure, and
rechecks grant identity after proof. Any missing coverage/closure returns generic
AccessDenied without hidden IDs/content/count. The read-only SQL stays inside the
shared access adapter; Procedures neither unwraps its owner nor widens any grant.
Direct immutable getters retain existing per-reference checks. Unsupported scoped
adapters without the completeness proof fail closed. Ordinary owner paths continue.

History collection, public histories, assessment, queue including empty queue,
and successful write/replay returns repeat proof at their return boundaries.
The frozen grant-changing controls reproduce the initially missing end proofs
and now pass unchanged. Full foreign-dependency grants provide a positive control;
whole requested-wing grants with hidden foreign lineage deny. Mixed finite scopes,
current finite IDs, room unions, hidden transitions and omitted ledger rows deny.

Write proof remains inside existing transactions, and original failed-write,
after-add rollback, correction/completion races, clean retry and lifecycle guards
remain green. Caller-owned outer transactions are explicitly provisional until
caller commit; frozen rollback/retry control confirms this documented boundary.

No remaining material scratch defect identified in this review. A lint-only
try/else movement is pending and requires one final replay. The actual PR source
has not changed: shared access-file coordination and branch application remain
outside this scratch source qualification. Earlier original packet remains exact,
and its local original36 PASS must not substitute for the newly found P1 boundary.
