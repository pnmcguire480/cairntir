"""Bounded additive round2 review with original evidence immutable."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
source = Path(sys.argv[1]).resolve()
label = sys.argv[2]
complete = len(sys.argv) > 3 and sys.argv[3] == "complete"
for folder, name in [(root, "freeze.json"), *[(root.parent, name) for name in (
    "freeze.json", "reviewer-fixture-v2-freeze.json", "edge-freeze.json", "sequence-freeze.json")]]:
    for filename, digest in json.loads((folder / name).read_text())["files"].items():
        assert hashlib.sha256((folder / filename).read_bytes()).hexdigest() == digest, filename
assert hashlib.sha256((root.parent / "r18-redteam-public.zip").read_bytes()).hexdigest() == "4e15f59541920d47a2f35b274254fee56af904c674c23603d942e0c3f1844f50"
env = dict(os.environ, PYTHONPATH=os.pathsep.join([str(source / "src"), str(root.parent), str(root)]),
    PYTHONDONTWRITEBYTECODE="1")
targets = ["completeness_probes"]
if complete:
    targets = ["probes_v2", "additional_probes_v2", "visibility_probes_v2", "edge_probes", "sequence_probes", *targets]
runtime = source / "src/cairntir/procedures.py"
digest = hashlib.sha256(runtime.read_bytes()).hexdigest()
command = [sys.executable, "-m", "unittest", "-v", *targets]
result = subprocess.run(command, cwd=root, env=env, capture_output=True, timeout=60,
    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
assert hashlib.sha256(runtime.read_bytes()).hexdigest() == digest, "source changed during run"
raw = result.stdout + result.stderr
log = root / (label + ".raw.log")
assert not log.exists(), "do not overwrite results"
log.write_bytes(raw)
def git(*args):
    return subprocess.run(["git", "-C", str(source), *args], capture_output=True, check=True).stdout
record = {"head": git("rev-parse", "HEAD").decode().strip(), "tree": git("rev-parse", "HEAD^{tree}").decode().strip(),
    "runtime_sha256": digest, "command": command, "exit_code": result.returncode,
    "freeze_sha256": hashlib.sha256((root / "freeze.json").read_bytes()).hexdigest(),
    "raw_sha256": hashlib.sha256(raw).hexdigest(), "original_zip_preserved": True,
    "status": git("status", "--porcelain").decode().strip()}
(root / (label + ".result.json")).write_text(json.dumps(record, indent=2) + "\n")
(root / (label + ".runtime.diff")).write_bytes(git("diff", "HEAD", "--", "src/cairntir/procedures.py"))
print(json.dumps(record, indent=2))
print(raw.decode(errors="replace")[-26000:])
sys.exit(result.returncode)
