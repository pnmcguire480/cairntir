# Round 2: parent P1 scope completeness correction

The original R18 packet, frozen probes, report and zip remain untouched.
Parent independent review reproduced omitted observations, latest corrections,
and completed reviews under finite drawer-ID scopes on head23c642. Earlier
review tested denied source dependencies, but did not test omitted ledger rows.
That earlier PASS does not qualify the newly reproduced P1 boundary.

Conservative repair contract: aggregate R18 history/assessment/writes/queue require
provably unrestricted read coverage for the entire requested wing. Current finite
ID coverage or unions of limited rooms cannot prove complete lineage and source
closure. A broad scope for another wing cannot supply this authority. A valid
whole-wing read scope may coexist with narrower scopes. Direct immutable getters
retain ordinary per-reference scoped authorization. AccessDenied is authoritative.
Runtime must not unwrap ScopedStore._owner, use raw SQL, or widen a grant.

Probes use real ScopedStore authorization/list/registry machinery with only its
live grant-loader seam replaced by inert in-memory dictionaries. No persisted
grants, access settings, or private runtime homes are changed. Tiny synthetic
stores and hash embeddings only; suites serial and process bounded60seconds.

Round2 is the last authorized product repair round. Original baseline/red/wrong
controls remain preserved. New tests freeze before repair; behavioral RED must
be recorded on current exact head. Outer transaction return values are provisional
until caller commit; rollback and clean retry are explicitly tested, with no new
transaction guard required. Existing failed-write rollback/retry controls remain
part of the final unchanged original36 suite.
